export const APP_VERSION = '0.42';
export const APP_VERSION_LABEL = `v ${APP_VERSION}`;
