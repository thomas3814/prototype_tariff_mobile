import { useMemo, useState } from 'react';
import { getNumericTariffValue } from '../shared/tariffFormat.js';

function MetricColumn({ label, rawValue, displayValue, maxNumericValue, highlighted = false }) {
  const numericValue = getNumericTariffValue(rawValue);
  const hasNumericBar = numericValue !== null && maxNumericValue > 0;
  const height = hasNumericBar
    ? `${Math.max((numericValue / maxNumericValue) * 100, numericValue > 0 ? 10 : 2)}%`
    : '0%';

  return (
    <div className={`metric-column ${highlighted ? 'metric-column--active' : 'metric-column--inactive'}`}>
      <div className="metric-column__stage">
        <span className="metric-column__value">{displayValue}</span>
        <span className="metric-column__center-label" aria-hidden="true">
          {label}
        </span>

        {hasNumericBar ? (
          <div
            className={`metric-column__bar ${numericValue === 0 ? 'metric-column__bar--zero' : ''}`}
            style={{ height }}
            aria-hidden="true"
          />
        ) : (
          <div className="metric-column__text-box" aria-hidden="true" />
        )}
      </div>
    </div>
  );
}

function GraphEntry({ entry, maxNumericValue }) {
  return (
    <div className="graph-entry-block">
      <div className="graph-entry__meta">
        <div className="graph-entry__origin-inline">원산지 기준 : {entry.originRule}</div>
        <div className="graph-entry__hs">HS {entry.hsCode}</div>
      </div>

      <div className="graph-entry">
        <div className="metric-columns">
          <MetricColumn
            label="협정관세"
            rawValue={entry.agreementTariffRaw}
            displayValue={entry.agreementTariffDisplay}
            maxNumericValue={maxNumericValue}
            highlighted={!entry.xMarked}
          />
          <MetricColumn
            label="기본관세"
            rawValue={entry.baseTariffRaw}
            displayValue={entry.baseTariffDisplay}
            maxNumericValue={maxNumericValue}
            highlighted={entry.xMarked}
          />
        </div>
      </div>
    </div>
  );
}

function CountryCard({ countryItem, maxNumericValue }) {
  return (
    <article className="graph-country-card">
      <header className="graph-country-card__header">
        <div>
          <h3>{countryItem.country}</h3>
        </div>
      </header>

      <div className="graph-country-card__entries">
        {countryItem.entries.map((entry) => (
          <GraphEntry key={entry.rowKey} entry={entry} maxNumericValue={maxNumericValue} />
        ))}
      </div>
    </article>
  );
}

function ExpandedContinentSection({ group, maxNumericValue, onToggleGroup }) {
  return (
    <section className="graph-strip">
      <header className="graph-strip__header graph-strip__header--stacked">
        <div className="graph-strip__action-row">
          <button
            className="button button--ghost button--compact graph-inline-toggle"
            type="button"
            onClick={() => onToggleGroup(group.continent)}
          >
            접기
          </button>
        </div>

        <div className="graph-strip__title">
          <strong>{group.continent}</strong>
          <span className="graph-strip__count">({group.countries.length})</span>
        </div>
      </header>

      <div className="graph-strip__countries">
        {group.countries.map((countryItem) => (
          <CountryCard
            key={countryItem.country}
            countryItem={countryItem}
            maxNumericValue={maxNumericValue}
          />
        ))}
      </div>
    </section>
  );
}

function CollapsedContinentSection({ group, onToggleGroup }) {
  return (
    <section className="graph-strip graph-strip--collapsed">
      <button
        className="graph-strip__collapsed-toggle"
        type="button"
        onClick={() => onToggleGroup(group.continent)}
      >
        <strong>{group.continent}</strong>
        <span className="graph-strip__collapsed-count">({group.countries.length})</span>
        <span className="graph-strip__collapsed-action">펼치기</span>
      </button>
    </section>
  );
}

function flattenCountries(graphModel) {
  return graphModel.groups.flatMap((group) => group.countries.map((countryItem) => ({
    ...countryItem,
    continent: countryItem.continent ?? group.continent,
  })));
}

function getGraphCountryCount(graphModel) {
  return graphModel.groups.reduce((count, group) => count + group.countries.length, 0);
}

function getSummaryEntry(entries) {
  if (!entries?.length) {
    return null;
  }

  return [...entries].sort((left, right) => {
    const leftNumeric = getNumericTariffValue(left.displayTariffRaw);
    const rightNumeric = getNumericTariffValue(right.displayTariffRaw);

    if (rightNumeric !== null && leftNumeric === null) {
      return 1;
    }

    if (rightNumeric === null && leftNumeric !== null) {
      return -1;
    }

    if (rightNumeric !== null && leftNumeric !== null && rightNumeric !== leftNumeric) {
      return rightNumeric - leftNumeric;
    }

    return left.sourceRowNumber - right.sourceRowNumber;
  })[0];
}

function getSummaryNumericValue(countryItem) {
  const summaryEntry = getSummaryEntry(countryItem.entries);

  if (!summaryEntry) {
    return null;
  }

  return getNumericTariffValue(summaryEntry.displayTariffRaw);
}

function getCountryListMaxNumericValue(countries) {
  return Math.max(...countries.map((countryItem) => getSummaryNumericValue(countryItem) ?? 0), 0);
}

function getCompactAxisLabel(axisTitle) {
  if (axisTitle === '수출국') {
    return '수출';
  }

  if (axisTitle === '수입국') {
    return '수입';
  }

  return axisTitle;
}

function getMobileBarTone(entry) {
  if (!entry) {
    return 'agreement';
  }

  return entry.displaySource === '기본관세' || entry.xMarked ? 'base' : 'agreement';
}

function MobileGraphSummary({ fixedCountryLabel, axisTitle, totalCountryCount }) {
  return (
    <div className="mobile-graph-summary" aria-label="모바일 그래프 요약 정보">
      <span className="mobile-graph-summary__item">
        <span className="mobile-graph-summary__label">고정:</span>
        <strong>{fixedCountryLabel}</strong>
      </span>
      <span className="mobile-graph-summary__item">
        <span className="mobile-graph-summary__label">축 :</span>
        <strong>{getCompactAxisLabel(axisTitle)}</strong>
      </span>
      <span className="mobile-graph-summary__item">
        <strong>{totalCountryCount}개국</strong>
      </span>
      <span className="mobile-graph-summary__legend" aria-label="막대 색상 범례">
        <span className="mobile-graph-summary__legend-item">
          <span className="mobile-graph-summary__dot mobile-graph-summary__dot--agreement" aria-hidden="true" />
          <span>협정</span>
        </span>
        <span className="mobile-graph-summary__legend-item">
          <span className="mobile-graph-summary__dot mobile-graph-summary__dot--base" aria-hidden="true" />
          <span>기본</span>
        </span>
      </span>
    </div>
  );
}

function MobileCountryDetail({ entry }) {
  return (
    <section className="mobile-country-detail">
      <header className="mobile-country-detail__header">
        <strong>HS {entry.hsCode}</strong>
        <span className="pill pill--accent mobile-country-detail__pill">
          {entry.displayTariffDisplay}
        </span>
      </header>

      <dl className="mobile-country-detail__grid">
        <div>
          <dt>원산지 기준</dt>
          <dd>{entry.originRule}</dd>
        </div>
        <div>
          <dt>적용 관세</dt>
          <dd>
            {entry.displayTariffDisplay}
            {' '}
            ({entry.displaySource})
          </dd>
        </div>
        <div>
          <dt>협정관세</dt>
          <dd>{entry.agreementTariffDisplay}</dd>
        </div>
        <div>
          <dt>기본관세</dt>
          <dd>{entry.baseTariffDisplay}</dd>
        </div>
      </dl>
    </section>
  );
}

function MobileCountryRow({ countryItem, maxNumericValue, isExpanded, onToggle, compact = false }) {
  const summaryEntry = getSummaryEntry(countryItem.entries);
  const summaryValue = summaryEntry?.displayTariffDisplay ?? '-';
  const summaryNumericValue = getSummaryNumericValue(countryItem);
  const width = summaryNumericValue !== null && maxNumericValue > 0
    ? `${Math.max((summaryNumericValue / maxNumericValue) * 100, summaryNumericValue > 0 ? 12 : 4)}%`
    : summaryNumericValue === 0
      ? '4%'
      : '0%';
  const rowClassName = [
    'mobile-country-row',
    isExpanded ? 'mobile-country-row--expanded' : '',
    compact ? 'mobile-country-row--compact' : '',
  ].filter(Boolean).join(' ');
  const summaryClassName = [
    'mobile-country-row__summary',
    compact ? 'mobile-country-row__summary--compact' : '',
  ].filter(Boolean).join(' ');
  const barToneClassName = [
    'mobile-country-row__bar',
    `mobile-country-row__bar--${getMobileBarTone(summaryEntry)}`,
    summaryNumericValue === 0 ? 'mobile-country-row__bar--zero' : '',
  ].filter(Boolean).join(' ');

  return (
    <article className={rowClassName}>
      <button
        className={summaryClassName}
        type="button"
        onClick={() => onToggle(countryItem.country)}
        aria-expanded={isExpanded}
        aria-controls={`mobile-country-detail-${countryItem.country}`}
      >
        <span className="mobile-country-row__label">{countryItem.country}</span>
        <span className="mobile-country-row__track" aria-hidden="true">
          <span
            className={barToneClassName}
            style={{ width }}
          />
        </span>
        <span className="mobile-country-row__value">{summaryValue}</span>
      </button>

      {isExpanded ? (
        <div className="mobile-country-row__details" id={`mobile-country-detail-${countryItem.country}`}>
          {countryItem.entries.map((entry) => (
            <MobileCountryDetail key={entry.rowKey} entry={entry} />
          ))}
        </div>
      ) : null}
    </article>
  );
}

function MobileCollapsedContinentChip({ group, onToggleGroup }) {
  return (
    <button
      className="mobile-continent-chip"
      type="button"
      onClick={() => onToggleGroup(group.continent)}
      aria-expanded="false"
      aria-label={`${group.continent}(${group.countries.length}) 펼치기`}
    >
      <span className="mobile-continent-chip__text">{`${group.continent}(${group.countries.length}) 펼치기`}</span>
    </button>
  );
}

function MobileContinentSection({
  group,
  maxNumericValue,
  expandedCountry,
  onToggleCountry,
  onToggleGroup,
}) {
  return (
    <section className="mobile-continent-section">
      <div className="mobile-continent-section__expanded-layout">
        <div className="mobile-continent-section__countries">
          {group.countries.map((countryItem) => (
            <MobileCountryRow
              key={countryItem.country}
              countryItem={countryItem}
              maxNumericValue={maxNumericValue}
              isExpanded={expandedCountry === countryItem.country}
              onToggle={onToggleCountry}
              compact
            />
          ))}
        </div>

        <button
          className="button button--ghost button--compact mobile-continent-section__side-toggle"
          type="button"
          onClick={() => onToggleGroup(group.continent)}
          aria-expanded="true"
          aria-label={`${group.continent}(${group.countries.length}) 접기`}
        >
          <span className="mobile-continent-section__side-inline">{`${group.continent}(${group.countries.length}) 접기`}</span>
        </button>
      </div>
    </section>
  );
}

function MobileCountryGraphSection({ graphModel, collapsedGroups, onToggleGroup }) {
  const [expandedCountry, setExpandedCountry] = useState('');
  const usesContinentGrouping = graphModel.mode === 'graph-by-import';

  const allCountries = useMemo(
    () => flattenCountries(graphModel),
    [graphModel],
  );
  const countries = useMemo(
    () => (usesContinentGrouping ? allCountries : allCountries.slice(0, 10)),
    [allCountries, usesContinentGrouping],
  );
  const maxNumericValue = useMemo(
    () => getCountryListMaxNumericValue(countries),
    [countries],
  );
  const totalCountryCount = usesContinentGrouping ? getGraphCountryCount(graphModel) : countries.length;
  const collapsedGroupList = useMemo(
    () => (usesContinentGrouping
      ? graphModel.groups.filter((group) => Boolean(collapsedGroups?.[group.continent]))
      : []),
    [graphModel, collapsedGroups, usesContinentGrouping],
  );
  const expandedGroupList = useMemo(
    () => (usesContinentGrouping
      ? graphModel.groups.filter((group) => !collapsedGroups?.[group.continent])
      : []),
    [graphModel, collapsedGroups, usesContinentGrouping],
  );

  function handleToggleCountry(country) {
    setExpandedCountry((current) => (current === country ? '' : country));
  }

  return (
    <section className="panel">
      <div className="panel__header panel__header--mobile-graph">
        <div>
          <h2>{graphModel.title}</h2>
        </div>
        <MobileGraphSummary
          fixedCountryLabel={graphModel.fixedCountryLabel}
          axisTitle={graphModel.axisTitle}
          totalCountryCount={totalCountryCount}
        />
      </div>

      {usesContinentGrouping ? (
        <>
          {collapsedGroupList.length ? (
            <div className="mobile-continent-chip-list" aria-label="접힌 대륙 펼치기 버튼 목록">
              {collapsedGroupList.map((group) => (
                <MobileCollapsedContinentChip
                  key={group.continent}
                  group={group}
                  onToggleGroup={onToggleGroup}
                />
              ))}
            </div>
          ) : null}

          <div className="mobile-continent-list" aria-label="모바일 대륙별 국가 그래프 목록">
            {expandedGroupList.map((group) => (
              <MobileContinentSection
                key={group.continent}
                group={group}
                maxNumericValue={maxNumericValue}
                expandedCountry={expandedCountry}
                onToggleCountry={handleToggleCountry}
                onToggleGroup={onToggleGroup}
              />
            ))}
          </div>
        </>
      ) : (
        <div className="mobile-graph-list" aria-label="모바일 국가 그래프 목록">
          {countries.map((countryItem) => (
            <MobileCountryRow
              key={countryItem.country}
              countryItem={countryItem}
              maxNumericValue={maxNumericValue}
              isExpanded={expandedCountry === countryItem.country}
              onToggle={handleToggleCountry}
            />
          ))}
        </div>
      )}
    </section>
  );
}

export default function GraphSection({
  graphModel,
  collapsedGroups,
  layoutMode = 'desktop',
  onToggleGroup,
}) {
  if (!graphModel) {
    return null;
  }

  if (layoutMode === 'mobile' && ['graph-by-export', 'graph-by-import'].includes(graphModel.mode)) {
    return (
      <MobileCountryGraphSection
        key={graphModel.title}
        graphModel={graphModel}
        collapsedGroups={collapsedGroups}
        onToggleGroup={onToggleGroup}
      />
    );
  }

  const expandedGroupCount = graphModel.groups.filter(
    (group) => !collapsedGroups[group.continent],
  ).length;
  const collapsedGroupCount = graphModel.groups.length - expandedGroupCount;

  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <h2>{graphModel.title}</h2>
        </div>
        <div className="graph-legend graph-legend--summary">
          <span className="pill">고정 기준: {graphModel.fixedCountryLabel}</span>
          <span className="pill pill--accent">축: {graphModel.axisTitle}</span>
          <span className="pill">펼침 {expandedGroupCount}개 / 접힘 {collapsedGroupCount}개</span>
        </div>
      </div>

      <div className="graph-board">
        <div className="graph-board__viewport">
          <div className="graph-board__track">
            {graphModel.groups.map((group) => {
              const isCollapsed = Boolean(collapsedGroups[group.continent]);

              return isCollapsed ? (
                <CollapsedContinentSection
                  key={group.continent}
                  group={group}
                  onToggleGroup={onToggleGroup}
                />
              ) : (
                <ExpandedContinentSection
                  key={group.continent}
                  group={group}
                  maxNumericValue={graphModel.maxNumericValue}
                  onToggleGroup={onToggleGroup}
                />
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
