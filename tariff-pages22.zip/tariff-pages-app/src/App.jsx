import { useEffect, useMemo, useState } from 'react';
import DetailSection from './components/DetailSection.jsx';
import EmptyState from './components/EmptyState.jsx';
import FilterPanel from './components/FilterPanel.jsx';
import GraphSection from './components/GraphSection.jsx';
import MetaPanel from './components/MetaPanel.jsx';
import {
  buildDetailCards,
  buildExportCountryGroups,
  buildGraphModel,
  buildImportCountryGroups,
  getProduct,
  getProductOptions,
  getViewMode,
} from './lib/tariffViewModel.js';

const DEFAULT_FILTERS = {
  productId: '',
  importContinent: '',
  importCountry: '',
  exportContinent: '',
  exportCountry: '',
};

async function loadSnapshot() {
  const response = await fetch(`${import.meta.env.BASE_URL}data/tariff-snapshot.json`, {
    cache: 'no-store',
  });

  if (!response.ok) {
    throw new Error(`데이터 파일을 불러오지 못했습니다. HTTP ${response.status}`);
  }

  return response.json();
}

export default function App() {
  const [snapshot, setSnapshot] = useState(null);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [collapsedGroups, setCollapsedGroups] = useState({});
  const [status, setStatus] = useState({
    loading: true,
    error: '',
  });

  useEffect(() => {
    let active = true;

    loadSnapshot()
      .then((data) => {
        if (!active) {
          return;
        }

        setSnapshot(data);
        setStatus({ loading: false, error: '' });
      })
      .catch((error) => {
        if (!active) {
          return;
        }

        setStatus({
          loading: false,
          error: error instanceof Error ? error.message : '알 수 없는 오류가 발생했습니다.',
        });
      });

    return () => {
      active = false;
    };
  }, []);

  const productOptions = useMemo(() => getProductOptions(snapshot), [snapshot]);
  const selectedProduct = useMemo(() => getProduct(snapshot, filters.productId), [snapshot, filters.productId]);
  const importGroups = useMemo(() => buildImportCountryGroups(selectedProduct), [selectedProduct]);
  const exportGroups = useMemo(() => buildExportCountryGroups(selectedProduct), [selectedProduct]);
  const viewMode = useMemo(() => getViewMode(filters), [filters]);
  const detailCards = useMemo(
    () => buildDetailCards(selectedProduct, filters.importCountry, filters.exportCountry),
    [selectedProduct, filters.importCountry, filters.exportCountry],
  );
  const graphModel = useMemo(
    () => buildGraphModel(selectedProduct, filters),
    [selectedProduct, filters],
  );

  function resetAllFilters() {
    setFilters(DEFAULT_FILTERS);
    setCollapsedGroups({});
  }

  function handleProductChange(productId) {
    setFilters({
      ...DEFAULT_FILTERS,
      productId,
    });
    setCollapsedGroups({});
  }

  function handleImportContinentChange(importContinent) {
    setFilters((current) => ({
      ...current,
      importContinent,
      importCountry: '',
    }));
  }

  function handleImportCountryChange(importCountry) {
    setFilters((current) => ({
      ...current,
      importCountry,
    }));
  }

  function handleExportContinentChange(exportContinent) {
    setFilters((current) => ({
      ...current,
      exportContinent,
      exportCountry: '',
    }));
  }

  function handleExportCountryChange(exportCountry) {
    setFilters((current) => ({
      ...current,
      exportCountry,
    }));
  }

  function toggleGraphGroup(continent) {
    setCollapsedGroups((current) => ({
      ...current,
      [continent]: !current[continent],
    }));
  }

  if (status.loading) {
    return (
      <div className="app-shell">
        <main className="app">
          <section className="panel loading-state">
            <h1>관세 조건 조회 시스템</h1>
            <p>데이터를 불러오는 중입니다.</p>
          </section>
        </main>
      </div>
    );
  }

  if (status.error) {
    return (
      <div className="app-shell">
        <main className="app">
          <section className="panel error-state">
            <h1>관세 조건 조회 시스템</h1>
            <p>{status.error}</p>
            <button className="button button--primary" type="button" onClick={() => window.location.reload()}>
              다시 시도
            </button>
          </section>
        </main>
      </div>
    );
  }

  return (
    <div className="app-shell">
      <main className="app">
        <header className="hero">
          <div>
            <span className="hero__eyebrow">Tariff Guide</span>
            <h1>관세 조건 조회 시스템</h1>
            <p>
              고정 엑셀 양식을 JSON 스냅샷으로 정규화하여, 모바일과 PC에서 동일한 기준으로 조회합니다.
            </p>
          </div>
        </header>

        <MetaPanel meta={snapshot?.meta} selectedProduct={selectedProduct} />

        <FilterPanel
          productOptions={productOptions}
          importGroups={importGroups}
          exportGroups={exportGroups}
          filters={filters}
          onProductChange={handleProductChange}
          onImportContinentChange={handleImportContinentChange}
          onImportCountryChange={handleImportCountryChange}
          onExportContinentChange={handleExportContinentChange}
          onExportCountryChange={handleExportCountryChange}
          onReset={resetAllFilters}
        />

        {viewMode === 'idle' ? <EmptyState type="idle" /> : null}
        {viewMode === 'waiting' ? <EmptyState type="waiting" /> : null}

        {viewMode === 'detail' && detailCards.length === 0 ? <EmptyState type="detail-empty" /> : null}
        {viewMode === 'detail' && detailCards.length > 0 ? (
          <DetailSection product={selectedProduct} cards={detailCards} />
        ) : null}

        {(viewMode === 'graph-by-export' || viewMode === 'graph-by-import') && graphModel ? (
          <GraphSection
            graphModel={graphModel}
            collapsedGroups={collapsedGroups}
            onToggleGroup={toggleGraphGroup}
          />
        ) : null}
      </main>
    </div>
  );
}
