import { getNumericTariffValue } from '../shared/tariffFormat.js';

function MetricBar({ label, rawValue, displayValue, maxNumericValue, highlighted = false }) {
  const numericValue = getNumericTariffValue(rawValue);
  const hasNumericBar = numericValue !== null && maxNumericValue > 0;
  const width = hasNumericBar ? `${(numericValue / maxNumericValue) * 100}%` : '0%';

  return (
    <div className="metric">
      <span className="metric__label">{label}</span>
      <div className={`metric__bar ${highlighted ? 'metric__bar--highlighted' : ''}`}>
        {hasNumericBar ? (
          <div className="metric__fill" style={{ width }} aria-hidden="true" />
        ) : (
          <div className="metric__fill metric__fill--text-only" aria-hidden="true" />
        )}
        <span className="metric__text">{displayValue}</span>
      </div>
    </div>
  );
}

function GraphEntry({ entry, maxNumericValue }) {
  return (
    <div className="graph-entry">
      <div className="graph-entry__header">
        <strong>HS {entry.hsCode}</strong>
        <span className="graph-entry__meta">원본 행 #{entry.sourceRowNumber}</span>
      </div>

      <MetricBar
        label="협정관세"
        rawValue={entry.agreementTariffRaw}
        displayValue={entry.agreementTariffDisplay}
        maxNumericValue={maxNumericValue}
        highlighted={!entry.xMarked}
      />
      <MetricBar
        label="기본관세"
        rawValue={entry.baseTariffRaw}
        displayValue={entry.baseTariffDisplay}
        maxNumericValue={maxNumericValue}
        highlighted={entry.xMarked}
      />

      <div className="graph-entry__footer">
        <span>표기 기준: {entry.displaySource}</span>
        {entry.xMarked ? <span>X 표기 감지</span> : null}
        <span>원산지 기준: {entry.originRule}</span>
      </div>
    </div>
  );
}

export default function GraphSection({
  graphModel,
  collapsedGroups,
  onToggleGroup,
}) {
  if (!graphModel) {
    return null;
  }

  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <h2>{graphModel.title}</h2>
          <p>{graphModel.subtitle}</p>
        </div>
        <div className="graph-legend">
          <span className="pill">고정 기준: {graphModel.fixedCountryLabel}</span>
          <span className="pill pill--accent">축: {graphModel.axisTitle}</span>
        </div>
      </div>

      <p className="graph-note">{graphModel.note}</p>

      <div className="graph-groups">
        {graphModel.groups.map((group) => {
          const isCollapsed = Boolean(collapsedGroups[group.continent]);

          return (
            <article key={group.continent} className="graph-group">
              <button
                className="graph-group__toggle"
                type="button"
                onClick={() => onToggleGroup(group.continent)}
                aria-expanded={!isCollapsed}
              >
                <span>
                  {group.continent} ({group.countries.length}개국)
                </span>
                <span>{isCollapsed ? '펼치기' : '접기'}</span>
              </button>

              {!isCollapsed ? (
                <div className="graph-group__content">
                  {group.countries.map((countryItem) => (
                    <section key={countryItem.country} className="graph-country">
                      <header className="graph-country__header">
                        <h3>{countryItem.country}</h3>
                        <span className="pill">
                          HS {countryItem.entries.length}건
                        </span>
                      </header>

                      <div className="graph-country__entries">
                        {countryItem.entries.map((entry) => (
                          <GraphEntry
                            key={entry.rowKey}
                            entry={entry}
                            maxNumericValue={graphModel.maxNumericValue}
                          />
                        ))}
                      </div>
                    </section>
                  ))}
                </div>
              ) : null}
            </article>
          );
        })}
      </div>
    </section>
  );
}
