import { formatDateTimeToKorea } from '../shared/tariffFormat.js';

export default function MetaPanel({ meta, selectedProduct }) {
  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <h2>데이터 정보</h2>
          <p>업로드된 최신 JSON 스냅샷 기준으로 조회합니다.</p>
        </div>
      </div>

      <div className="meta-grid">
        <article className="meta-card">
          <span className="meta-card__label">원본 파일</span>
          <strong className="meta-card__value">{meta?.sourceFileName ?? '-'}</strong>
        </article>

        <article className="meta-card">
          <span className="meta-card__label">업로드 일시</span>
          <strong className="meta-card__value">
            {formatDateTimeToKorea(meta?.uploadedAt ?? meta?.extractedAt)}
          </strong>
        </article>

        <article className="meta-card">
          <span className="meta-card__label">원본 파일 수정일</span>
          <strong className="meta-card__value">
            {formatDateTimeToKorea(meta?.sourceFileLastModified)}
          </strong>
        </article>

        <article className="meta-card">
          <span className="meta-card__label">현재 제품</span>
          <strong className="meta-card__value">{selectedProduct?.label ?? '선택 전'}</strong>
        </article>
      </div>

      <ul className="meta-notes">
        {(meta?.notes ?? []).map((note) => (
          <li key={note}>{note}</li>
        ))}
      </ul>
    </section>
  );
}
