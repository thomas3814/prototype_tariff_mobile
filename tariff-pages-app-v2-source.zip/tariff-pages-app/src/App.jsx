import { useEffect, useMemo, useState } from 'react';
import DetailSection from './components/DetailSection.jsx';
import EmptyState from './components/EmptyState.jsx';
import FilterPanel from './components/FilterPanel.jsx';
import GraphSection from './components/GraphSection.jsx';
import MetaPanel from './components/MetaPanel.jsx';
import {
  buildDetailCards,
  buildExportCountryGroups,
  buildGraphModel,
  buildImportCountryGroups,
  getProduct,
  getProductOptions,
  getViewMode,
} from './lib/tariffViewModel.js';

const DEFAULT_FILTERS = {
  productId: '',
  importContinent: '',
  importCountry: '',
  exportContinent: '',
  exportCountry: '',
};

const LOCAL_SNAPSHOT_STORAGE_KEY = 'tariff-pages:local-snapshot:v2';

async function loadSnapshot() {
  const response = await fetch(`${import.meta.env.BASE_URL}data/tariff-snapshot.json`, {
    cache: 'no-store',
  });

  if (!response.ok) {
    throw new Error(`데이터 파일을 불러오지 못했습니다. HTTP ${response.status}`);
  }

  return response.json();
}

function getSnapshotTimestamp(snapshot) {
  const rawValue =
    snapshot?.meta?.uploadedAt ??
    snapshot?.meta?.extractedAt ??
    snapshot?.meta?.sourceFileLastModified ??
    null;
  const timestamp = rawValue ? Date.parse(rawValue) : Number.NaN;
  return Number.isNaN(timestamp) ? 0 : timestamp;
}

function decorateSnapshot(snapshot, storageMode) {
  return {
    ...snapshot,
    meta: {
      ...snapshot?.meta,
      storageMode,
    },
  };
}

function loadLocalSnapshot() {
  if (typeof window === 'undefined') {
    return null;
  }

  try {
    const rawValue = window.localStorage.getItem(LOCAL_SNAPSHOT_STORAGE_KEY);

    if (!rawValue) {
      return null;
    }

    const parsed = JSON.parse(rawValue);
    return decorateSnapshot(parsed, 'local-upload');
  } catch (error) {
    window.localStorage.removeItem(LOCAL_SNAPSHOT_STORAGE_KEY);
    return null;
  }
}

function saveLocalSnapshot(snapshot) {
  if (typeof window === 'undefined') {
    return;
  }

  window.localStorage.setItem(LOCAL_SNAPSHOT_STORAGE_KEY, JSON.stringify(snapshot));
}

function clearLocalSnapshot() {
  if (typeof window === 'undefined') {
    return;
  }

  window.localStorage.removeItem(LOCAL_SNAPSHOT_STORAGE_KEY);
}

function choosePreferredSnapshot(publishedSnapshot, localSnapshot) {
  if (!publishedSnapshot) {
    return localSnapshot;
  }

  if (!localSnapshot) {
    return publishedSnapshot;
  }

  return getSnapshotTimestamp(localSnapshot) >= getSnapshotTimestamp(publishedSnapshot)
    ? localSnapshot
    : publishedSnapshot;
}

async function parseWorkbookFile(file) {
  const { parseTariffWorkbook } = await import('./lib/tariffSnapshotParser.js');
  const fileBuffer = await file.arrayBuffer();

  return parseTariffWorkbook({
    fileBuffer,
    sourceFileName: file.name,
    sourceFileLastModified: Number.isFinite(file.lastModified)
      ? new Date(file.lastModified).toISOString()
      : new Date().toISOString(),
    uploadedAt: new Date().toISOString(),
  });
}

export default function App() {
  const [bootstrapLocalSnapshot] = useState(() => loadLocalSnapshot());
  const [snapshot, setSnapshot] = useState(bootstrapLocalSnapshot);
  const [publishedSnapshot, setPublishedSnapshot] = useState(null);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [collapsedGroups, setCollapsedGroups] = useState({});
  const [status, setStatus] = useState({
    loading: !bootstrapLocalSnapshot,
    error: '',
  });
  const [updateState, setUpdateState] = useState({
    loading: false,
    error: '',
    message: bootstrapLocalSnapshot
      ? '이 브라우저에 저장된 업데이트 데이터로 먼저 표시했습니다.'
      : '',
  });

  useEffect(() => {
    let active = true;
    const localSnapshot = bootstrapLocalSnapshot;

    loadSnapshot()
      .then((data) => {
        if (!active) {
          return;
        }

        const normalizedPublishedSnapshot = decorateSnapshot(data, 'published');
        setPublishedSnapshot(normalizedPublishedSnapshot);

        const preferredSnapshot = choosePreferredSnapshot(
          normalizedPublishedSnapshot,
          localSnapshot,
        );

        setSnapshot(preferredSnapshot);
        setStatus({ loading: false, error: '' });

        if (preferredSnapshot?.meta?.storageMode === 'published' && localSnapshot) {
          clearLocalSnapshot();
        }
      })
      .catch((error) => {
        if (!active) {
          return;
        }

        if (localSnapshot) {
          setSnapshot(localSnapshot);
          setStatus({ loading: false, error: '' });
          setUpdateState((current) => ({
            ...current,
            message:
              current.message ||
              '공개 데이터 로딩에 실패하여 이 브라우저에 저장된 업데이트 데이터로 계속 표시합니다.',
          }));
          return;
        }

        setStatus({
          loading: false,
          error: error instanceof Error ? error.message : '알 수 없는 오류가 발생했습니다.',
        });
      });

    return () => {
      active = false;
    };
  }, [bootstrapLocalSnapshot]);

  const productOptions = useMemo(() => getProductOptions(snapshot), [snapshot]);
  const selectedProduct = useMemo(() => getProduct(snapshot, filters.productId), [snapshot, filters.productId]);
  const importGroups = useMemo(() => buildImportCountryGroups(selectedProduct), [selectedProduct]);
  const exportGroups = useMemo(() => buildExportCountryGroups(selectedProduct), [selectedProduct]);
  const viewMode = useMemo(() => getViewMode(filters), [filters]);
  const detailCards = useMemo(
    () => buildDetailCards(selectedProduct, filters.importCountry, filters.exportCountry),
    [selectedProduct, filters.importCountry, filters.exportCountry],
  );
  const graphModel = useMemo(
    () => buildGraphModel(selectedProduct, filters),
    [selectedProduct, filters],
  );

  function resetAllFilters() {
    setFilters(DEFAULT_FILTERS);
    setCollapsedGroups({});
  }

  function handleProductChange(productId) {
    setFilters({
      ...DEFAULT_FILTERS,
      productId,
    });
    setCollapsedGroups({});
  }

  function handleImportContinentChange(importContinent) {
    setFilters((current) => ({
      ...current,
      importContinent,
      importCountry: '',
    }));
  }

  function handleImportCountryChange(importCountry) {
    setFilters((current) => ({
      ...current,
      importCountry,
    }));
  }

  function handleExportContinentChange(exportContinent) {
    setFilters((current) => ({
      ...current,
      exportContinent,
      exportCountry: '',
    }));
  }

  function handleExportCountryChange(exportCountry) {
    setFilters((current) => ({
      ...current,
      exportCountry,
    }));
  }

  function toggleGraphGroup(continent) {
    setCollapsedGroups((current) => ({
      ...current,
      [continent]: !current[continent],
    }));
  }

  async function handleUpdateFileSelected(file) {
    if (!file) {
      return;
    }

    setUpdateState({
      loading: true,
      error: '',
      message: '',
    });

    try {
      const nextSnapshot = decorateSnapshot(await parseWorkbookFile(file), 'local-upload');
      saveLocalSnapshot(nextSnapshot);
      setSnapshot(nextSnapshot);
      resetAllFilters();
      setUpdateState({
        loading: false,
        error: '',
        message: `${file.name} 파일을 반영했습니다. 현재 브라우저에서는 새로고침 후에도 최신 값이 유지됩니다.`,
      });
    } catch (error) {
      setUpdateState({
        loading: false,
        error: error instanceof Error ? error.message : '엑셀 파일 처리 중 오류가 발생했습니다.',
        message: '',
      });
    }
  }

  function handleRestorePublishedData() {
    clearLocalSnapshot();
    resetAllFilters();

    if (publishedSnapshot) {
      setSnapshot(publishedSnapshot);
      setUpdateState({
        loading: false,
        error: '',
        message: '배포된 공개 데이터 기준으로 되돌렸습니다.',
      });
      return;
    }

    window.location.reload();
  }

  if (status.loading) {
    return (
      <div className="app-shell">
        <main className="app">
          <section className="panel loading-state">
            <h1>관세 조건 조회 시스템</h1>
            <p>데이터를 불러오는 중입니다.</p>
          </section>
        </main>
      </div>
    );
  }

  if (status.error) {
    return (
      <div className="app-shell">
        <main className="app">
          <section className="panel error-state">
            <h1>관세 조건 조회 시스템</h1>
            <p>{status.error}</p>
            <button className="button button--primary" type="button" onClick={() => window.location.reload()}>
              다시 시도
            </button>
          </section>
        </main>
      </div>
    );
  }

  return (
    <div className="app-shell">
      <main className="app">
        <header className="hero">
          <div>
            <span className="hero__eyebrow">Tariff Guide</span>
            <h1>관세 조건 조회 시스템</h1>
            <p>
              고정 엑셀 양식을 JSON 스냅샷으로 정규화하여, 모바일과 PC에서 동일한 기준으로 조회합니다.
            </p>
          </div>
        </header>

        <MetaPanel
          meta={snapshot?.meta}
          selectedProduct={selectedProduct}
          isUpdating={updateState.loading}
          updateError={updateState.error}
          updateMessage={updateState.message}
          onUpdateFileSelected={handleUpdateFileSelected}
          onRestorePublishedData={handleRestorePublishedData}
        />

        <FilterPanel
          productOptions={productOptions}
          importGroups={importGroups}
          exportGroups={exportGroups}
          filters={filters}
          onProductChange={handleProductChange}
          onImportContinentChange={handleImportContinentChange}
          onImportCountryChange={handleImportCountryChange}
          onExportContinentChange={handleExportContinentChange}
          onExportCountryChange={handleExportCountryChange}
          onReset={resetAllFilters}
        />

        {viewMode === 'idle' ? <EmptyState type="idle" /> : null}
        {viewMode === 'waiting' ? <EmptyState type="waiting" /> : null}

        {viewMode === 'detail' && detailCards.length === 0 ? <EmptyState type="detail-empty" /> : null}
        {viewMode === 'detail' && detailCards.length > 0 ? (
          <DetailSection product={selectedProduct} cards={detailCards} />
        ) : null}

        {(viewMode === 'graph-by-export' || viewMode === 'graph-by-import') && graphModel ? (
          <GraphSection
            graphModel={graphModel}
            collapsedGroups={collapsedGroups}
            onToggleGroup={toggleGraphGroup}
          />
        ) : null}
      </main>
    </div>
  );
}
