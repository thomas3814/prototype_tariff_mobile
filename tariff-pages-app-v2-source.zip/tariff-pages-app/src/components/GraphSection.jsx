import { getNumericTariffValue } from '../shared/tariffFormat.js';

function MetricBar({ label, rawValue, displayValue, maxNumericValue, highlighted = false }) {
  const numericValue = getNumericTariffValue(rawValue);
  const hasNumericBar = numericValue !== null && maxNumericValue > 0;
  const width = hasNumericBar ? `${(numericValue / maxNumericValue) * 100}%` : '0%';

  return (
    <div className="metric">
      <span className="metric__label">{label}</span>
      <div className={`metric__bar ${highlighted ? 'metric__bar--highlighted' : ''}`}>
        {hasNumericBar ? (
          <div className="metric__fill" style={{ width }} aria-hidden="true" />
        ) : (
          <div className="metric__fill metric__fill--text-only" aria-hidden="true" />
        )}
        <span className="metric__text">{displayValue}</span>
      </div>
    </div>
  );
}

function GraphEntry({ entry, maxNumericValue }) {
  return (
    <div className="graph-entry">
      <div className="graph-entry__header">
        <strong>HS {entry.hsCode}</strong>
        <span className="graph-entry__meta">원본 행 #{entry.sourceRowNumber}</span>
      </div>

      <MetricBar
        label="협정관세"
        rawValue={entry.agreementTariffRaw}
        displayValue={entry.agreementTariffDisplay}
        maxNumericValue={maxNumericValue}
        highlighted={!entry.xMarked}
      />
      <MetricBar
        label="기본관세"
        rawValue={entry.baseTariffRaw}
        displayValue={entry.baseTariffDisplay}
        maxNumericValue={maxNumericValue}
        highlighted={entry.xMarked}
      />

      <div className="graph-entry__footer">
        <span>표기 기준: {entry.displaySource}</span>
        {entry.xMarked ? <span>X 표기 감지</span> : null}
        <span>원산지 기준: {entry.originRule}</span>
      </div>
    </div>
  );
}

function CountryCard({ countryItem, maxNumericValue }) {
  return (
    <article className="graph-country-card">
      <header className="graph-country-card__header">
        <div>
          <h3>{countryItem.country}</h3>
          <p>{countryItem.continent}</p>
        </div>
        <span className="pill">HS {countryItem.entries.length}건</span>
      </header>

      <div className="graph-country-card__entries">
        {countryItem.entries.map((entry) => (
          <GraphEntry
            key={entry.rowKey}
            entry={entry}
            maxNumericValue={maxNumericValue}
          />
        ))}
      </div>
    </article>
  );
}

export default function GraphSection({
  graphModel,
  collapsedGroups,
  onToggleGroup,
}) {
  if (!graphModel) {
    return null;
  }

  const visibleGroups = graphModel.groups.filter((group) => !collapsedGroups[group.continent]);
  const collapsedGroupCount = graphModel.groups.length - visibleGroups.length;

  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <h2>{graphModel.title}</h2>
          <p>{graphModel.subtitle}</p>
        </div>
        <div className="graph-legend">
          <span className="pill">고정 기준: {graphModel.fixedCountryLabel}</span>
          <span className="pill pill--accent">축: {graphModel.axisTitle}</span>
        </div>
      </div>

      <p className="graph-note">{graphModel.note}</p>

      <div className="graph-group-switches" role="group" aria-label="대륙 표시 토글">
        {graphModel.groups.map((group) => {
          const isCollapsed = Boolean(collapsedGroups[group.continent]);

          return (
            <button
              key={group.continent}
              className={`graph-group-pill ${isCollapsed ? 'graph-group-pill--collapsed' : ''}`}
              type="button"
              onClick={() => onToggleGroup(group.continent)}
              aria-pressed={!isCollapsed}
            >
              <span>{group.continent}</span>
              <span>{group.countries.length}개국</span>
              <span>{isCollapsed ? '펼치기' : '접기'}</span>
            </button>
          );
        })}
      </div>

      <div className="graph-board">
        <div className="graph-board__summary">
          <span className="pill">좌우 스크롤로 국가 카드를 이동하세요.</span>
          <span className="pill">
            현재 표시 대륙 {visibleGroups.length}개 / 접힌 대륙 {collapsedGroupCount}개
          </span>
        </div>

        {visibleGroups.length > 0 ? (
          <div className="graph-board__viewport">
            <div className="graph-board__track">
              {visibleGroups.map((group) => (
                <section key={group.continent} className="graph-strip">
                  <header className="graph-strip__header">
                    <strong>{group.continent}</strong>
                    <span className="pill">{group.countries.length}개국</span>
                  </header>

                  <div className="graph-strip__countries">
                    {group.countries.map((countryItem) => (
                      <CountryCard
                        key={countryItem.country}
                        countryItem={countryItem}
                        maxNumericValue={graphModel.maxNumericValue}
                      />
                    ))}
                  </div>
                </section>
              ))}
            </div>
          </div>
        ) : (
          <div className="graph-board__empty">
            <p>모든 대륙이 접혀 있습니다. 상단 버튼에서 최소 1개 대륙을 펼쳐주세요.</p>
          </div>
        )}
      </div>
    </section>
  );
}
