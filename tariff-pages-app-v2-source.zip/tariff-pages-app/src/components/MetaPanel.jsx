import { useRef } from 'react';
import { formatDateTimeToKorea } from '../shared/tariffFormat.js';

const EXCEL_ACCEPT_VALUE = [
  '.xlsx',
  '.xlsm',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-excel.sheet.macroEnabled.12',
].join(',');

export default function MetaPanel({
  meta,
  selectedProduct,
  isUpdating,
  updateError,
  updateMessage,
  onUpdateFileSelected,
  onRestorePublishedData,
}) {
  const fileInputRef = useRef(null);
  const isUsingLocalUpload = meta?.storageMode === 'local-upload';

  function handleOpenFilePicker() {
    fileInputRef.current?.click();
  }

  function handleFileChange(event) {
    const [selectedFile] = event.target.files ?? [];

    if (selectedFile) {
      onUpdateFileSelected(selectedFile);
    }

    event.target.value = '';
  }

  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <h2>데이터 정보</h2>
          <p>
            {isUsingLocalUpload
              ? '이 브라우저에 반영된 최신 엑셀 기준으로 조회합니다.'
              : '배포된 최신 JSON 스냅샷 기준으로 조회합니다.'}
          </p>
        </div>
        <div className="graph-legend">
          <span className={`pill ${isUsingLocalUpload ? 'pill--accent' : ''}`}>
            {isUsingLocalUpload ? '현재 브라우저 반영 데이터' : '배포 데이터'}
          </span>
        </div>
      </div>

      <div className="meta-grid">
        <article className="meta-card meta-card--source">
          <div className="meta-card__top">
            <span className="meta-card__label">원본 파일</span>
            <div className="meta-card__actions">
              <button
                className="button button--secondary button--compact"
                type="button"
                onClick={handleOpenFilePicker}
                disabled={isUpdating}
              >
                {isUpdating ? '업데이트 중...' : 'Update'}
              </button>
              {isUsingLocalUpload ? (
                <button
                  className="button button--ghost button--compact"
                  type="button"
                  onClick={onRestorePublishedData}
                  disabled={isUpdating}
                >
                  공개 데이터 복원
                </button>
              ) : null}
            </div>
          </div>

          <strong className="meta-card__value">{meta?.sourceFileName ?? '-'}</strong>
          <span className="meta-card__subtext">
            관세조건표 엑셀 파일을 선택하면 즉시 다시 분석하여 최신 값을 반영합니다.
          </span>

          <input
            ref={fileInputRef}
            className="sr-only"
            type="file"
            accept={EXCEL_ACCEPT_VALUE}
            onChange={handleFileChange}
          />
        </article>

        <article className="meta-card">
          <span className="meta-card__label">업로드 일시</span>
          <strong className="meta-card__value">
            {formatDateTimeToKorea(meta?.uploadedAt ?? meta?.extractedAt)}
          </strong>
        </article>

        <article className="meta-card">
          <span className="meta-card__label">원본 파일 수정일</span>
          <strong className="meta-card__value">
            {formatDateTimeToKorea(meta?.sourceFileLastModified)}
          </strong>
        </article>

        <article className="meta-card">
          <span className="meta-card__label">현재 제품</span>
          <strong className="meta-card__value">{selectedProduct?.label ?? '선택 전'}</strong>
        </article>
      </div>

      {updateMessage ? <p className="meta-status meta-status--success">{updateMessage}</p> : null}
      {updateError ? <p className="meta-status meta-status--error">{updateError}</p> : null}

      <ul className="meta-notes">
        {(meta?.notes ?? []).map((note) => (
          <li key={note}>{note}</li>
        ))}
      </ul>
    </section>
  );
}
