# 관세 조건 조회 시스템

고정 엑셀 양식의 관세 조견표를 **정규화 JSON**으로 변환한 뒤, **React + Vite + GitHub Pages**로 조회하는 프로젝트입니다.

## 핵심 설계

- **조회 화면은 정적 사이트**입니다.
- **엑셀 원본은 브라우저에서 직접 계속 해석하지 않고**, 관리자만 로컬 스크립트로 `xlsx -> json` 변환 후 저장소에 반영합니다.
- GitHub Pages는 정적 호스팅이므로, **특정 사용자만 업로드**해야 한다는 요구사항은 **저장소 push 권한**으로 제어합니다.
- 조회는 공개로 열고, 업데이트는 **repo collaborator / maintainer**만 수행합니다.

## 기술 스택

- React
- Vite
- JavaScript
- ExcelJS (엑셀 파싱)

## 현재 반영된 요구사항

- 제품 드롭다운은 엑셀 시트를 기준으로 구성합니다.
- 제외 시트:
  - 이어버드
  - BD Player
  - 무선스피커 별매용 배터리
- 업로드 일시 표시
- 수입국 21개 / 수출국 10개 제한
- 수입국/수출국 미선택(null) 그래프 조건 수정 반영
  - **수입국만 선택** → 수출국 그래프
  - **수출국만 선택** → 수입국 그래프
- 수입국/수출국 둘 다 선택 시
  - 원산지 결정 기준 표시
  - 관세율 표시
  - **동일 국가 복수 HS Code 다건 표시**
- 협정관세 셀에 X 표기가 있으면
  - 상세 조회 표시 관세율은 **기본관세** 우선
- 그래프는 **협정관세 / 기본관세를 함께 비교**
- 그래프는 대륙 단위 접기/펼치기 지원
- 초기화 버튼으로 전체 기본 상태 복귀

## 개발 시작

```bash
npm install
npm run dev
```

## 최신 엑셀을 반영하는 방법

관리자(저장소 push 권한 보유자)만 아래 과정을 수행합니다.

```bash
npm run sync:data -- "/absolute/path/to/관세조견표.xlsx"
```

기본 출력 위치는 아래 파일입니다.

```bash
public/data/tariff-snapshot.json
```

그 다음 생성된 JSON을 커밋하고 push 하면 GitHub Pages가 자동 배포됩니다.

## 빌드

```bash
npm run build
npm run preview
```

## GitHub Pages 배포

1. 저장소의 **Settings → Pages** 로 이동
2. Source를 **GitHub Actions** 로 선택
3. 기본 브랜치에 push
4. `.github/workflows/deploy.yml` 이 자동 배포 수행

`vite.config.js` 는 GitHub Pages용 base 경로를 자동 계산합니다.

- `https://<owner>.github.io/` 저장소면 `/`
- `https://<owner>.github.io/<repo>/` 저장소면 `/<repo>/`

필요하면 수동으로 덮어쓸 수도 있습니다.

```bash
VITE_BASE_PATH=/my-repo/ npm run build
```

## 폴더 구조

```text
src/
  components/          화면 컴포넌트
  lib/                 조회용 view model
  shared/              프론트/파서 공통 상수 및 포맷 함수
scripts/
  tariffWorkbookParser.mjs
  generateTariffSnapshot.mjs
public/data/
  tariff-snapshot.json
.github/workflows/
  deploy.yml
```

## 운영 가이드

- 사용자는 항상 `public/data/tariff-snapshot.json` 만 조회합니다.
- 엑셀 양식이 크게 바뀌면 먼저 `scripts/tariffWorkbookParser.mjs` 의 헤더 위치 판별 로직을 점검하세요.
- X 표시는 셀 값이 아니라 **대각선 border** 입니다.
- 일부 제품은 동일 수입국에 복수 HS Code 행이 있으므로, 단일 결과로 합치지 않습니다.
