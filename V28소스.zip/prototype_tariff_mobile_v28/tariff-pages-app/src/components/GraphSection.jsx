import { useMemo, useState } from 'react';
import { getNumericTariffValue } from '../shared/tariffFormat.js';

function getSelectedTariffKey(entry) {
  if (!entry) {
    return 'agreement';
  }

  return entry.displaySource === '기본관세' || entry.xMarked ? 'base' : 'agreement';
}

function getSelectedTariffLabel(entry) {
  return getSelectedTariffKey(entry) === 'base' ? '기본' : '협정';
}

function getSummaryEntry(entries) {
  if (!entries?.length) {
    return null;
  }

  return [...entries].sort((left, right) => {
    const leftNumeric = getNumericTariffValue(left.displayTariffRaw);
    const rightNumeric = getNumericTariffValue(right.displayTariffRaw);

    if (rightNumeric !== null && leftNumeric === null) {
      return 1;
    }

    if (rightNumeric === null && leftNumeric !== null) {
      return -1;
    }

    if (rightNumeric !== null && leftNumeric !== null && rightNumeric !== leftNumeric) {
      return rightNumeric - leftNumeric;
    }

    return left.sourceRowNumber - right.sourceRowNumber;
  })[0];
}

function getCompactAxisLabel(axisTitle) {
  if (axisTitle === '수출국') {
    return '수출';
  }

  if (axisTitle === '수입국') {
    return '수입';
  }

  return axisTitle;
}

function getSafeDomId(value) {
  return String(value)
    .trim()
    .replace(/[^0-9A-Za-z가-힣_-]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'row';
}

function getCountryItemKey(countryItem, group) {
  return `${group.continent}-${countryItem.country}`;
}

function getTotalCountryCount(groups) {
  return groups.reduce((count, group) => count + group.countries.length, 0);
}

function getContinentToggleLabel(group, actionLabel) {
  return `${group.continent}(${group.countries.length}) ${actionLabel}`;
}

function getUniformContinentToggleWidth(groups) {
  const longestLabelLength = groups.reduce(
    (maxLength, group) => Math.max(maxLength, getContinentToggleLabel(group, '접기').length),
    0,
  );

  return `${Math.max(4.6, Math.min(6.2, longestLabelLength * 0.42 + 1.15))}rem`;
}

function MobileGraphSummary({ fixedCountryLabel, axisTitle, totalCountryCount }) {
  return (
    <div className="mobile-graph-summary" aria-label="모바일 그래프 요약 정보">
      <span className="mobile-graph-summary__item">
        <span className="mobile-graph-summary__label">고정:</span>
        <strong>{fixedCountryLabel}</strong>
      </span>
      <span className="mobile-graph-summary__item">
        <span className="mobile-graph-summary__label">축 :</span>
        <strong>{getCompactAxisLabel(axisTitle)}</strong>
      </span>
      <span className="mobile-graph-summary__item">
        <strong>{totalCountryCount}개국</strong>
      </span>
      <span className="mobile-graph-summary__legend" aria-label="값 색상 범례">
        <span className="mobile-graph-summary__legend-item">
          <span className="mobile-graph-summary__dot mobile-graph-summary__dot--agreement" aria-hidden="true" />
          <span>협정</span>
        </span>
        <span className="mobile-graph-summary__legend-item">
          <span className="mobile-graph-summary__dot mobile-graph-summary__dot--base" aria-hidden="true" />
          <span>기본</span>
        </span>
      </span>
    </div>
  );
}

function DesktopLegend() {
  return (
    <span className="comparison-legend" aria-label="관세 범례">
      <span className="comparison-legend__item">
        <span className="comparison-legend__dot comparison-legend__dot--agreement" aria-hidden="true" />
        <span>협정</span>
      </span>
      <span className="comparison-legend__item">
        <span className="comparison-legend__dot comparison-legend__dot--base" aria-hidden="true" />
        <span>기본</span>
      </span>
      <span className="comparison-legend__hint">채택 관세 강조 표기</span>
    </span>
  );
}

function ComparisonMiniTable({ entry, compact = false }) {
  const selectedKey = getSelectedTariffKey(entry);
  const className = [
    'comparison-mini-table',
    compact ? 'comparison-mini-table--compact' : '',
  ].filter(Boolean).join(' ');

  return (
    <div className={className} aria-label="협정 및 기본 관세 비교 표">
      <span className="comparison-mini-table__head">협정</span>
      <span className="comparison-mini-table__head">기본</span>

      <span
        className={[
          'comparison-mini-table__cell',
          'comparison-mini-table__cell--agreement',
          selectedKey === 'agreement' ? 'comparison-mini-table__cell--selected' : '',
        ].filter(Boolean).join(' ')}
      >
        <span className="comparison-mini-table__value">{entry?.agreementTariffDisplay ?? '-'}</span>
        {selectedKey === 'agreement' ? (
          <span className="comparison-mini-table__badge">채택</span>
        ) : null}
      </span>

      <span
        className={[
          'comparison-mini-table__cell',
          'comparison-mini-table__cell--base',
          selectedKey === 'base' ? 'comparison-mini-table__cell--selected' : '',
        ].filter(Boolean).join(' ')}
      >
        <span className="comparison-mini-table__value">{entry?.baseTariffDisplay ?? '-'}</span>
        {selectedKey === 'base' ? (
          <span className="comparison-mini-table__badge">채택</span>
        ) : null}
      </span>
    </div>
  );
}

function ComparisonEntryMeta({ entry, compact = false }) {
  const selectedLabel = getSelectedTariffLabel(entry);
  const className = [
    'comparison-entry-meta',
    compact ? 'comparison-entry-meta--compact' : '',
  ].filter(Boolean).join(' ');

  return (
    <dl className={className}>
      <div>
        <dt>원산지 기준</dt>
        <dd>{entry.originRule}</dd>
      </div>
      <div>
        <dt>HS</dt>
        <dd>{entry.hsCode}</dd>
      </div>
      <div>
        <dt>채택 관세</dt>
        <dd>
          {entry.displayTariffDisplay}
          {' '}
          ({selectedLabel})
        </dd>
      </div>
    </dl>
  );
}

function DesktopCountryCard({ countryItem }) {
  return (
    <article className="comparison-country-card">
      <header className="comparison-country-card__header">
        <h3>{countryItem.country}</h3>
      </header>

      <div className="comparison-country-card__entries">
        {countryItem.entries.map((entry) => (
          <section key={entry.rowKey} className="comparison-country-card__entry">
            <ComparisonMiniTable entry={entry} compact />
            <details className="comparison-country-card__details">
              <summary>세부 정보</summary>
              <ComparisonEntryMeta entry={entry} compact />
            </details>
          </section>
        ))}
      </div>
    </article>
  );
}

function DesktopExpandedContinentSection({ group, onToggleGroup }) {
  return (
    <section className="comparison-strip">
      <header className="comparison-strip__header comparison-strip__header--stacked">
        <div className="comparison-strip__action-row">
          <button
            className="button button--ghost button--compact comparison-inline-toggle"
            type="button"
            onClick={() => onToggleGroup(group.continent)}
          >
            접기
          </button>
        </div>

        <div className="comparison-strip__title">
          <strong>{group.continent}</strong>
          <span className="comparison-strip__count">({group.countries.length})</span>
        </div>
      </header>

      <div className="comparison-strip__countries">
        {group.countries.map((countryItem) => (
          <DesktopCountryCard key={countryItem.country} countryItem={countryItem} />
        ))}
      </div>
    </section>
  );
}

function DesktopCollapsedContinentSection({ group, onToggleGroup }) {
  return (
    <section className="comparison-strip comparison-strip--collapsed">
      <button
        className="graph-strip__collapsed-toggle"
        type="button"
        onClick={() => onToggleGroup(group.continent)}
      >
        <strong>{group.continent}</strong>
        <span className="graph-strip__collapsed-count">({group.countries.length})</span>
        <span className="graph-strip__collapsed-action">펼치기</span>
      </button>
    </section>
  );
}

function DesktopGroupedComparisonSection({ graphModel, collapsedGroups, onToggleGroup }) {
  const expandedGroupCount = graphModel.groups.filter(
    (group) => !collapsedGroups[group.continent],
  ).length;
  const collapsedGroupCount = graphModel.groups.length - expandedGroupCount;
  const totalCountryCount = getTotalCountryCount(graphModel.groups);

  return (
    <section className="panel">
      <div className="panel__header panel__header--comparison">
        <div>
          <h2>{graphModel.title}</h2>
        </div>
        <div className="graph-legend graph-legend--summary comparison-header-summary">
          <span className="pill">고정 기준: {graphModel.fixedCountryLabel}</span>
          <span className="pill pill--accent">축: {graphModel.axisTitle}</span>
          <span className="pill">총 {totalCountryCount}개국</span>
          <span className="pill">펼침 {expandedGroupCount}개 / 접힘 {collapsedGroupCount}개</span>
          <DesktopLegend />
        </div>
      </div>

      <div className="comparison-board">
        <div className="comparison-board__viewport">
          <div className="comparison-board__track">
            {graphModel.groups.map((group) => {
              const isCollapsed = Boolean(collapsedGroups[group.continent]);

              return isCollapsed ? (
                <DesktopCollapsedContinentSection
                  key={group.continent}
                  group={group}
                  onToggleGroup={onToggleGroup}
                />
              ) : (
                <DesktopExpandedContinentSection
                  key={group.continent}
                  group={group}
                  onToggleGroup={onToggleGroup}
                />
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

function MobileCountryDetailEntry({ entry }) {
  const selectedLabel = getSelectedTariffLabel(entry);

  return (
    <section className="comparison-mobile-detail-item">
      <header className="comparison-mobile-detail-item__header">
        <strong>HS {entry.hsCode}</strong>
        <span className="comparison-source-pill">{selectedLabel} 채택</span>
      </header>
      <ComparisonMiniTable entry={entry} compact />
      <ComparisonEntryMeta entry={entry} compact />
    </section>
  );
}

function MobileCountryCard({ group, countryItem, isExpanded, onToggle }) {
  const countryKey = getCountryItemKey(countryItem, group);
  const summaryEntry = getSummaryEntry(countryItem.entries);
  const detailId = `mobile-country-detail-${getSafeDomId(countryKey)}`;
  const articleClassName = [
    'comparison-mobile-card',
    isExpanded ? 'comparison-mobile-card--expanded' : '',
  ].filter(Boolean).join(' ');

  return (
    <article className={articleClassName}>
      <button
        className="comparison-mobile-card__summary"
        type="button"
        onClick={() => onToggle(countryKey)}
        aria-expanded={isExpanded}
        aria-controls={detailId}
        title={countryItem.country}
      >
        <span className="comparison-mobile-card__header">
          <strong className="comparison-mobile-card__country">{countryItem.country}</strong>
          <span className="comparison-mobile-card__action">{isExpanded ? '접기' : '상세'}</span>
        </span>
        <ComparisonMiniTable entry={summaryEntry} compact />
      </button>

      {isExpanded ? (
        <div className="comparison-mobile-card__details" id={detailId}>
          {countryItem.entries.map((entry) => (
            <MobileCountryDetailEntry key={entry.rowKey} entry={entry} />
          ))}
        </div>
      ) : null}
    </article>
  );
}

function MobileCollapsedContinentChip({ group, onToggleGroup }) {
  return (
    <button
      className="mobile-continent-chip"
      type="button"
      onClick={() => onToggleGroup(group.continent)}
      aria-expanded="false"
      aria-label={`${group.continent}(${group.countries.length}) 펼치기`}
    >
      <span className="mobile-continent-chip__text">{`${group.continent}(${group.countries.length}) 펼치기`}</span>
    </button>
  );
}

function MobileContinentSection({
  group,
  expandedCountryKey,
  onToggleCountry,
  onToggleGroup,
  uniformToggleWidth,
}) {
  const sideToggleLabel = getContinentToggleLabel(group, '접기');
  const sectionStyle = uniformToggleWidth ? { '--mobile-side-toggle-width': uniformToggleWidth } : undefined;

  return (
    <section className="mobile-continent-section" style={sectionStyle}>
      <div className="mobile-continent-section__expanded-layout">
        <div className="mobile-continent-section__countries comparison-mobile-grid">
          {group.countries.map((countryItem) => {
            const countryKey = getCountryItemKey(countryItem, group);

            return (
              <MobileCountryCard
                key={countryKey}
                group={group}
                countryItem={countryItem}
                isExpanded={expandedCountryKey === countryKey}
                onToggle={onToggleCountry}
              />
            );
          })}
        </div>

        <button
          className="button button--ghost button--compact mobile-continent-section__side-toggle"
          type="button"
          onClick={() => onToggleGroup(group.continent)}
          aria-expanded="true"
          aria-label={sideToggleLabel}
          title={sideToggleLabel}
        >
          <span className="mobile-continent-section__side-inline">{sideToggleLabel}</span>
        </button>
      </div>
    </section>
  );
}

function MobileGroupedComparisonSection({ graphModel, collapsedGroups, onToggleGroup }) {
  const [expandedCountryKey, setExpandedCountryKey] = useState('');
  const totalCountryCount = useMemo(
    () => getTotalCountryCount(graphModel.groups),
    [graphModel],
  );
  const collapsedGroupList = useMemo(
    () => graphModel.groups.filter((group) => Boolean(collapsedGroups?.[group.continent])),
    [graphModel, collapsedGroups],
  );
  const expandedGroupList = useMemo(
    () => graphModel.groups.filter((group) => !collapsedGroups?.[group.continent]),
    [graphModel, collapsedGroups],
  );
  const uniformToggleWidth = useMemo(
    () => getUniformContinentToggleWidth(graphModel.groups),
    [graphModel],
  );

  function handleToggleCountry(countryKey) {
    setExpandedCountryKey((current) => (current === countryKey ? '' : countryKey));
  }

  return (
    <section className="panel">
      <div className="panel__header panel__header--mobile-graph panel__header--comparison-mobile">
        <div>
          <h2>{graphModel.title}</h2>
        </div>
        <MobileGraphSummary
          fixedCountryLabel={graphModel.fixedCountryLabel}
          axisTitle={graphModel.axisTitle}
          totalCountryCount={totalCountryCount}
        />
      </div>

      {collapsedGroupList.length ? (
        <div className="mobile-continent-chip-list" aria-label="접힌 대륙 펼치기 버튼 목록">
          {collapsedGroupList.map((group) => (
            <MobileCollapsedContinentChip
              key={group.continent}
              group={group}
              onToggleGroup={onToggleGroup}
            />
          ))}
        </div>
      ) : null}

      <div className="mobile-continent-list" aria-label="모바일 대륙별 국가 비교 목록">
        {expandedGroupList.map((group) => (
          <MobileContinentSection
            key={group.continent}
            group={group}
            expandedCountryKey={expandedCountryKey}
            onToggleCountry={handleToggleCountry}
            onToggleGroup={onToggleGroup}
            uniformToggleWidth={uniformToggleWidth}
          />
        ))}
      </div>
    </section>
  );
}

export default function GraphSection({
  graphModel,
  collapsedGroups,
  layoutMode = 'desktop',
  onToggleGroup,
}) {
  if (!graphModel) {
    return null;
  }

  if (layoutMode === 'mobile') {
    return (
      <MobileGroupedComparisonSection
        key={`${graphModel.title}-${graphModel.mode}-mobile`}
        graphModel={graphModel}
        collapsedGroups={collapsedGroups}
        onToggleGroup={onToggleGroup}
      />
    );
  }

  return (
    <DesktopGroupedComparisonSection
      key={`${graphModel.title}-${graphModel.mode}-desktop`}
      graphModel={graphModel}
      collapsedGroups={collapsedGroups}
      onToggleGroup={onToggleGroup}
    />
  );
}
