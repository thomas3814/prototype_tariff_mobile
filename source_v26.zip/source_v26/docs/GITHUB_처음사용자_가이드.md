# GitHub 처음 사용자 가이드

이 문서는 **GitHub를 잘 모르는 분**이 아래 저장소를 보고,

`https://github.com/thomas3814/prototype_tariff_mobile`

코드를 가져온 뒤 자신의 저장소에서 다시 공개하는 과정을 최대한 쉽게 설명합니다.

---

## 가장 쉬운 선택 기준

### 그냥 코드만 받아보고 싶다
- **Code → Download ZIP**

### 내 GitHub에서 계속 관리하고 싶다
- **Fork**

### 내 웹 주소로 다른 사람도 접속하게 하고 싶다
- **Fork 후 GitHub Pages 설정**

---

## 1. GitHub 가입

1. GitHub에 접속합니다.
2. **Sign up**을 누릅니다.
3. 이메일, 비밀번호, 사용자 이름을 입력합니다.
4. 이메일 인증까지 마칩니다.

가입이 끝나면 GitHub 저장소를 열 수 있습니다.

---

## 2. 원본 저장소 방문

아래 주소로 이동합니다.

`https://github.com/thomas3814/prototype_tariff_mobile`

저장소 첫 화면에서 다음을 할 수 있습니다.
- 코드 보기
- Download ZIP
- Fork
- README 읽기

---

## 3. 방법 A — Fork로 가장 쉽게 내 프로젝트 만들기

이 방법이 가장 추천됩니다.

### 3-1. Fork 만들기

1. 저장소 우측 상단의 **Fork** 버튼을 누릅니다.
2. **Create fork**를 누릅니다.
3. 잠시 후 내 계정 아래에 같은 저장소가 생성됩니다.

예시

```text
원본: https://github.com/thomas3814/prototype_tariff_mobile
내 포크: https://github.com/내아이디/prototype_tariff_mobile
```

### 3-2. GitHub Pages 켜기

1. 내 포크 저장소로 들어갑니다.
2. **Settings** 탭으로 이동합니다.
3. 왼쪽 메뉴에서 **Pages**를 누릅니다.
4. **Build and deployment**에서 **Source**를 **GitHub Actions**로 선택합니다.

### 3-3. Actions가 막혀 있으면 허용하기

1. 저장소 상단의 **Actions** 탭으로 이동합니다.
2. 실행이 막혀 있으면 **Enable** 또는 워크플로 허용 버튼을 눌러줍니다.

### 3-4. 내 데이터로 바꾸기

다음 파일을 바꾸면 됩니다.

```text
tariff-pages-app/source-data/tariff-source.xlsx
```

바꾸는 방법은 2가지입니다.

#### 방법 1: GitHub 웹에서 파일 교체
1. 해당 폴더로 이동합니다.
2. 기존 파일을 삭제하거나 새 파일로 교체합니다.
3. **Commit changes**를 누릅니다.

#### 방법 2: Codespaces 또는 내 PC에서 수정 후 push
1. 저장소를 clone 합니다.
2. 파일을 교체합니다.
3. commit / push 합니다.

### 3-5. 배포 주소 확인

커밋 후 GitHub Actions가 성공하면 아래 형식의 주소로 접속할 수 있습니다.

```text
https://내GitHub아이디.github.io/저장소이름/
```

예시

```text
https://thomas3814.github.io/prototype_tariff_mobile/
```

---

## 4. 방법 B — ZIP으로 받은 뒤 내 새 저장소에 업로드하기

Git을 잘 몰라도 가능한 방식입니다.

### 4-1. ZIP 다운로드

1. 원본 저장소에서 **Code** 버튼을 누릅니다.
2. **Download ZIP**을 누릅니다.
3. 압축을 풉니다.

### 4-2. 새 저장소 만들기

1. GitHub 우측 상단의 **+** 메뉴에서 **New repository**를 누릅니다.
2. 저장소 이름을 입력합니다.
3. **Create repository**를 누릅니다.

### 4-3. 파일 업로드

1. 새 저장소 첫 화면에서 **Add file → Upload files**를 누릅니다.
2. 압축을 푼 파일을 전부 업로드합니다.
3. **Commit changes**를 누릅니다.

### 4-4. Pages 설정

1. **Settings → Pages**로 이동합니다.
2. **Source = GitHub Actions**로 선택합니다.
3. 필요하면 **Actions** 탭에서 워크플로를 허용합니다.

### 4-5. 공개 주소 확인

배포가 끝나면 아래 형식으로 접속합니다.

```text
https://내GitHub아이디.github.io/새저장소이름/
```

---

## 5. 화면만 조금 수정하고 싶을 때

주로 아래 폴더를 보면 됩니다.

```text
tariff-pages-app/src/
```

예를 들면:
- 화면 배치 수정
- 모바일 / PC 모드 수정
- 그래프 bar 수정
- 접기 / 펼치기 UI 수정

---

## 6. 로컬에서 실행하는 방법

```bash
cd tariff-pages-app
npm install
npm run dev
```

브라우저에서 안내된 로컬 주소를 열면 됩니다.

배포용 빌드:

```bash
npm run lint
npm run build
```

---

## 7. 이 저장소에서 가장 중요한 위치

### 원본 엑셀
```text
tariff-pages-app/source-data/tariff-source.xlsx
```

### 화면 코드
```text
tariff-pages-app/src/
```

### 자동 배포 설정
```text
.github/workflows/prototype_tariff_mobile-root-github-upload-deploy.yml
```

---

## 8. 자주 생기는 문제

### 문제 1. 사이트 대신 README가 열립니다
**Settings → Pages → Source**가 **GitHub Actions**인지 먼저 확인하세요.

### 문제 2. 저장소 이름을 바꿨더니 주소가 바뀌었습니다
정상입니다. 주소는 항상 아래 형식입니다.

```text
https://내아이디.github.io/저장소이름/
```

### 문제 3. 더 이상 사이트를 공개하고 싶지 않습니다
**Settings → Pages**에서 게시를 중지하면 됩니다.

### 문제 4. Git이 어렵습니다
GitHub 웹에서 파일 업로드와 Commit만으로도 운영 가능합니다.

---

## 9. 추천 사용 순서

초보자라면 아래 순서를 추천합니다.

1. 원본 저장소 열기
2. README 읽기
3. Fork
4. Pages를 GitHub Actions로 설정
5. `tariff-source.xlsx` 교체
6. Actions 성공 확인
7. 내 Pages 주소 공유
