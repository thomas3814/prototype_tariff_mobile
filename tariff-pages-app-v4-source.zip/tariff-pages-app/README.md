# 관세 조건 조회 시스템

고정 엑셀 양식의 관세 조견표를 **정규화 JSON**으로 변환한 뒤, **React + Vite** 화면에서 모바일/PC 공통 기준으로 조회하는 프로젝트입니다.

## 현재 구조

- 공개 사용자는 항상 최신 **게시된 JSON 스냅샷**을 조회합니다.
- 관리자는 브라우저에서 Excel 파일을 선택하면:
  1. 브라우저에서 Excel → JSON 정규화
  2. Supabase Storage 업로드
  3. `tariff_publish_state` 갱신
  4. 접속 중인 사용자 화면 자동 갱신
- Supabase 환경 변수가 없으면 `public/data/tariff-snapshot.json` 정적 파일로 fallback 합니다.

## 기술 스택

- React
- Vite
- JavaScript
- ExcelJS (엑셀 파싱)
- Supabase JS (관리자 인증 + 스냅샷 배포)

## 반영 요구사항 요약

- 상단 제품/국가 조건 영역 제목: **관세 조회 조건**
- 별도 상단 타이틀 제거
- 제품 선택 후
  - 수입국만 선택 → 수출국 그래프
  - 수출국만 선택 → 수입국 그래프
  - 둘 다 선택 → HS별 상세 결과
- 동일 국가의 복수 HS Code는 모두 유지
- 그래프는 국가 카드 가로 스크롤 구조
- 대륙 단위 접기/펼치기 지원
- 그래프 카드 안에서
  - `원본 행 #NN` 제거
  - `원산지 기준`을 상단 2줄 표기로 이동
  - `비표기 / 표기 기준` 배지 제거
  - `X 표기 감지` 문구 제거
- 데이터 정보 영역은 최하단 배치
- Update 버튼은 관리자 로그인 후 활성화
- Excel 업데이트 시 모든 사용자에게 최신값 즉시 반영

## 개발 시작

```bash
npm install
npm run dev
```

## 로컬 정적 JSON 갱신

Supabase 없이 정적 JSON 만 갱신하고 싶을 때 사용합니다.

```bash
npm run sync:data -- "/absolute/path/to/관세조견표.xlsx"
```

출력 기본 경로:

```text
public/data/tariff-snapshot.json
```

## Supabase 연동 순서

### 1) 환경 변수 준비

`.env.example` 를 복사해서 `.env.local` 을 만든 뒤 값 입력:

```bash
cp .env.example .env.local
```

필수 값:

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

### 2) SQL 초기 설정 실행

Supabase SQL Editor 에서 아래 파일을 실행합니다.

```text
supabase/setup.sql
```

### 3) 관리자 이메일 등록

SQL Editor 에서 관리자 계정을 추가합니다.

```sql
insert into public.admin_users (email)
values ('your-admin@example.com')
on conflict (email) do nothing;
```

### 4) 관리자 사용자 생성

Supabase Auth에서 위 이메일 계정을 생성하고 비밀번호를 설정합니다.

### 5) 최신 배포 확인

앱 하단 `데이터 정보` 영역에서 관리자 로그인 후 `Update` 버튼으로 Excel 파일을 반영합니다.

## 빌드

```bash
npm run lint
npm run build
npm run preview
```

## GitHub Pages 배포

GitHub Actions 빌드에 Supabase 값을 주입하려면 Repository Secrets 에 아래 값을 등록합니다.

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_SUPABASE_SNAPSHOT_BUCKET` (선택)
- `VITE_SUPABASE_PUBLISH_TABLE` (선택)
- `VITE_SUPABASE_ADMIN_TABLE` (선택)
- `VITE_SUPABASE_PUBLISH_ROW_ID` (선택)

프로젝트 안의 `.github/workflows/deploy.yml` 은 위 Secrets 를 사용하도록 반영되어 있습니다.

## 폴더 구조

```text
src/
  components/          화면 컴포넌트
  lib/                 조회/배포용 로직
  shared/              프론트/파서 공통 상수 및 포맷 함수
scripts/
  generateTariffSnapshot.mjs
supabase/
  setup.sql            Supabase 초기 설정 SQL
public/data/
  tariff-snapshot.json
```

## 운영 메모

- 사용자는 브라우저에서 원본 Excel 을 직접 읽지 않고, 게시된 JSON 만 조회합니다.
- 엑셀 양식이 크게 바뀌면 먼저 `src/lib/tariffSnapshotParser.js` 의 헤더 판별 로직을 점검하세요.
- 일부 제품은 동일 수입국에 복수 HS Code 행이 있으므로 단일 결과로 합치지 않습니다.
