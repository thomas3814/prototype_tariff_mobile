import { useRef, useState } from 'react';
import { formatDateTimeToKorea } from '../shared/tariffFormat.js';

const EXCEL_ACCEPT_VALUE = [
  '.xlsx',
  '.xlsm',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-excel.sheet.macroEnabled.12',
].join(',');

function AdminAccessCard({
  isPublishApiEnabled,
  adminUser,
  isAdminAuthenticated,
  authReady,
  authLoading,
  authError,
  authMessage,
  onAdminSignIn,
  onAdminSignOut,
}) {
  const [credentials, setCredentials] = useState({
    username: '',
    password: '',
  });

  async function handleSubmit(event) {
    event.preventDefault();
    await onAdminSignIn(credentials);
    setCredentials((current) => ({
      ...current,
      password: '',
    }));
  }

  return (
    <article className="meta-card meta-card--wide">
      <span className="meta-card__label">업데이트 권한</span>

      {!isPublishApiEnabled ? (
        <>
          <strong className="meta-card__value">실시간 반영 API 미설정</strong>
          <span className="meta-card__subtext">
            .env.local 의 VITE_PUBLISH_API_BASE_URL 을 설정하면 단일 ID/PW 로그인 후 모든 사용자에게 공용 반영할 수 있습니다.
          </span>
        </>
      ) : null}

      {isPublishApiEnabled && !isAdminAuthenticated ? (
        <>
          <strong className="meta-card__value">
            {authReady ? '관리자 로그인 필요' : '권한 확인 중'}
          </strong>
          <span className="meta-card__subtext">
            관리자 ID/PW로 로그인하면 Update 버튼으로 새 관세조건표를 공용 반영할 수 있습니다.
          </span>

          <form className="admin-auth-form" onSubmit={handleSubmit}>
            <div className="admin-auth-grid">
              <label className="field">
                <span className="field__label">관리자 ID</span>
                <input
                  className="field__control field__control--input"
                  type="text"
                  value={credentials.username}
                  onChange={(event) => setCredentials((current) => ({
                    ...current,
                    username: event.target.value,
                  }))}
                  placeholder="admin"
                  autoComplete="username"
                  disabled={authLoading}
                  required
                />
              </label>

              <label className="field">
                <span className="field__label">비밀번호</span>
                <input
                  className="field__control field__control--input"
                  type="password"
                  value={credentials.password}
                  onChange={(event) => setCredentials((current) => ({
                    ...current,
                    password: event.target.value,
                  }))}
                  placeholder="비밀번호 입력"
                  autoComplete="current-password"
                  disabled={authLoading}
                  required
                />
              </label>
            </div>

            <div className="meta-card__actions">
              <button className="button button--primary" type="submit" disabled={authLoading}>
                {authLoading ? '로그인 중...' : '관리자 로그인'}
              </button>
            </div>
          </form>
        </>
      ) : null}

      {isPublishApiEnabled && isAdminAuthenticated ? (
        <>
          <strong className="meta-card__value">{adminUser?.username ?? '-'}</strong>
          <span className="meta-card__subtext">
            현재 계정은 관세조건표 업데이트 권한이 있습니다.
          </span>

          <div className="meta-card__actions">
            <button
              className="button button--ghost button--compact"
              type="button"
              onClick={onAdminSignOut}
              disabled={authLoading}
            >
              {authLoading ? '처리 중...' : '로그아웃'}
            </button>
          </div>
        </>
      ) : null}

      {authMessage ? <p className="meta-status meta-status--success">{authMessage}</p> : null}
      {authError ? <p className="meta-status meta-status--error">{authError}</p> : null}
    </article>
  );
}

export default function MetaPanel({
  meta,
  selectedProduct,
  dataSourceLabel,
  isPublishApiEnabled,
  adminUser,
  isAdminAuthenticated,
  authReady,
  authLoading,
  authError,
  authMessage,
  isUpdating,
  updateError,
  updateMessage,
  onAdminSignIn,
  onAdminSignOut,
  onUpdateFileSelected,
}) {
  const fileInputRef = useRef(null);
  const updateDisabled = !isPublishApiEnabled || !isAdminAuthenticated || isUpdating || authLoading;

  function handleOpenFilePicker() {
    if (updateDisabled) {
      return;
    }

    fileInputRef.current?.click();
  }

  function handleFileChange(event) {
    const [selectedFile] = event.target.files ?? [];

    if (selectedFile) {
      void onUpdateFileSelected(selectedFile);
    }

    event.target.value = '';
  }

  function getSourceSubtext() {
    if (!isPublishApiEnabled) {
      return 'Cloudflare Worker API를 연결하면 단일 ID/PW 로그인 후 모든 사용자에게 공용 반영할 수 있습니다.';
    }

    if (isAdminAuthenticated) {
      return '관세조건표 Excel 파일을 선택하면 공용 최신 스냅샷으로 반영합니다.';
    }

    return 'Update 버튼은 관리자 로그인 후 활성화됩니다.';
  }

  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <h2>데이터 정보</h2>
        </div>
        <div className="graph-legend">
          <span className={`pill ${isPublishApiEnabled ? 'pill--accent' : ''}`}>{dataSourceLabel}</span>
        </div>
      </div>

      <div className="meta-grid">
        <article className="meta-card meta-card--source">
          <div className="meta-card__top">
            <span className="meta-card__label">원본 파일</span>
            <div className="meta-card__actions">
              <button
                className="button button--secondary button--compact"
                type="button"
                onClick={handleOpenFilePicker}
                disabled={updateDisabled}
                title={updateDisabled ? '관리자 로그인 후 사용 가능합니다.' : '최신 관세조건표를 반영합니다.'}
              >
                {isUpdating ? '업데이트 중...' : 'Update'}
              </button>
            </div>
          </div>

          <strong className="meta-card__value">{meta?.sourceFileName ?? '-'}</strong>
          <span className="meta-card__subtext">{getSourceSubtext()}</span>

          <input
            ref={fileInputRef}
            className="sr-only"
            type="file"
            accept={EXCEL_ACCEPT_VALUE}
            onChange={handleFileChange}
          />
        </article>

        <article className="meta-card">
          <span className="meta-card__label">업로드 일시</span>
          <strong className="meta-card__value">
            {formatDateTimeToKorea(meta?.uploadedAt ?? meta?.extractedAt)}
          </strong>
        </article>

        <article className="meta-card">
          <span className="meta-card__label">원본 파일 수정일</span>
          <strong className="meta-card__value">
            {formatDateTimeToKorea(meta?.sourceFileLastModified)}
          </strong>
        </article>

        <article className="meta-card">
          <span className="meta-card__label">현재 제품</span>
          <strong className="meta-card__value">{selectedProduct?.label ?? '선택 전'}</strong>
        </article>

        {meta?.publishedByEmail ? (
          <article className="meta-card">
            <span className="meta-card__label">최근 반영자</span>
            <strong className="meta-card__value">{meta.publishedByEmail}</strong>
          </article>
        ) : null}

        <AdminAccessCard
          isPublishApiEnabled={isPublishApiEnabled}
          adminUser={adminUser}
          isAdminAuthenticated={isAdminAuthenticated}
          authReady={authReady}
          authLoading={authLoading}
          authError={authError}
          authMessage={authMessage}
          onAdminSignIn={onAdminSignIn}
          onAdminSignOut={onAdminSignOut}
        />
      </div>

      {updateMessage ? <p className="meta-status meta-status--success">{updateMessage}</p> : null}
      {updateError ? <p className="meta-status meta-status--error">{updateError}</p> : null}
    </section>
  );
}
