const messages = {
  idle: {
    title: '제품을 선택해주세요.',
    description: '제품을 먼저 선택하면 수입국과 수출국 선택이 활성화됩니다.',
  },
  waiting: {
    title: '국가를 선택해주세요.',
    description:
      '수입국만 선택하면 수출국 그래프, 수출국만 선택하면 수입국 그래프, 둘 다 선택하면 HS별 상세 결과가 표시됩니다.',
  },
  'detail-empty': {
    title: '해당 조합의 데이터가 없습니다.',
    description: '선택한 제품/수입국/수출국 조합에 매칭되는 HS 행을 찾지 못했습니다.',
  },
};

export default function EmptyState({ type }) {
  const message = messages[type] ?? messages.waiting;

  return (
    <section className="panel empty-state">
      <h2>{message.title}</h2>
      <p>{message.description}</p>
    </section>
  );
}
