const encoder = new TextEncoder();

function getCorsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization,Content-Type',
    'Access-Control-Max-Age': '86400',
  };
}

function jsonResponse(body, init = {}) {
  const headers = new Headers(init.headers ?? {});
  const corsHeaders = getCorsHeaders();

  Object.entries(corsHeaders).forEach(([key, value]) => {
    headers.set(key, value);
  });

  headers.set('Content-Type', 'application/json; charset=utf-8');
  headers.set('Cache-Control', 'no-store');

  return new Response(`${JSON.stringify(body, null, 2)}
`, {
    ...init,
    headers,
  });
}

function emptyResponse(status = 204) {
  return new Response(null, {
    status,
    headers: getCorsHeaders(),
  });
}

function errorResponse(message, status = 400) {
  return jsonResponse({ error: message }, { status });
}

async function sha256Hex(text) {
  const digest = await crypto.subtle.digest('SHA-256', encoder.encode(text));
  return [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, '0')).join('');
}

function bytesToBase64(bytes) {
  let binary = '';

  bytes.forEach((value) => {
    binary += String.fromCharCode(value);
  });

  return btoa(binary);
}

function base64UrlEncodeText(text) {
  const bytes = encoder.encode(text);
  return bytesToBase64(bytes)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '');
}

function base64UrlDecodeText(value) {
  const normalized = value
    .replace(/-/g, '+')
    .replace(/_/g, '/');
  const padded = normalized + '==='.slice((normalized.length + 3) % 4);
  const binary = atob(padded);
  const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

async function signPayload(payloadBase64Url, secret) {
  const key = await crypto.subtle.importKey(
    'raw',
    encoder.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  const signature = await crypto.subtle.sign('HMAC', key, encoder.encode(payloadBase64Url));
  return bytesToBase64(new Uint8Array(signature))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '');
}

function timingSafeEqual(left, right) {
  if (typeof left !== 'string' || typeof right !== 'string' || left.length !== right.length) {
    return false;
  }

  let result = 0;

  for (let index = 0; index < left.length; index += 1) {
    result |= left.charCodeAt(index) ^ right.charCodeAt(index);
  }

  return result === 0;
}

async function createAuthToken(username, env) {
  const ttlSeconds = Number.parseInt(env.TOKEN_TTL_SECONDS ?? '28800', 10) || 28800;
  const expiresAtMs = Date.now() + (ttlSeconds * 1000);
  const payload = {
    sub: username,
    exp: Math.floor(expiresAtMs / 1000),
  };
  const payloadBase64Url = base64UrlEncodeText(JSON.stringify(payload));
  const signature = await signPayload(payloadBase64Url, env.TOKEN_SECRET);

  return {
    token: `${payloadBase64Url}.${signature}`,
    expiresAt: new Date(expiresAtMs).toISOString(),
  };
}

async function verifyAuthToken(token, env) {
  if (!token || !env.TOKEN_SECRET) {
    return null;
  }

  const [payloadBase64Url, signature] = token.split('.');

  if (!payloadBase64Url || !signature) {
    return null;
  }

  const expectedSignature = await signPayload(payloadBase64Url, env.TOKEN_SECRET);

  if (!timingSafeEqual(signature, expectedSignature)) {
    return null;
  }

  let payload;

  try {
    payload = JSON.parse(base64UrlDecodeText(payloadBase64Url));
  } catch (error) {
    return null;
  }

  if (!payload?.sub || !payload?.exp) {
    return null;
  }

  if ((payload.exp * 1000) <= Date.now()) {
    return null;
  }

  return payload;
}

function getBearerToken(request) {
  const header = request.headers.get('Authorization') ?? '';

  if (!header.startsWith('Bearer ')) {
    return '';
  }

  return header.slice('Bearer '.length).trim();
}

async function requireAdmin(request, env) {
  const token = getBearerToken(request);
  const payload = await verifyAuthToken(token, env);

  if (!payload) {
    throw Object.assign(new Error('관리자 인증이 필요합니다.'), { status: 401 });
  }

  return payload;
}

function validateSnapshot(snapshot) {
  if (!snapshot || typeof snapshot !== 'object') {
    throw Object.assign(new Error('snapshot payload 가 비어 있습니다.'), { status: 400 });
  }

  if (!snapshot?.uiConfig?.products || !snapshot?.products) {
    throw Object.assign(new Error('snapshot payload 형식이 올바르지 않습니다.'), { status: 400 });
  }
}

async function handleLogin(request, env) {
  if (!env.ADMIN_USERNAME || !env.ADMIN_PASSWORD_HASH || !env.TOKEN_SECRET) {
    return errorResponse('Worker 비밀값이 설정되지 않았습니다.', 500);
  }

  const payload = await request.json().catch(() => null);
  const username = String(payload?.username ?? '').trim();
  const password = String(payload?.password ?? '');

  if (!username || !password) {
    return errorResponse('관리자 ID와 비밀번호를 모두 입력해주세요.', 400);
  }

  if (username !== env.ADMIN_USERNAME) {
    return errorResponse('관리자 인증에 실패했습니다.', 401);
  }

  const passwordHash = await sha256Hex(password);

  if (!timingSafeEqual(passwordHash, env.ADMIN_PASSWORD_HASH)) {
    return errorResponse('관리자 인증에 실패했습니다.', 401);
  }

  const tokenInfo = await createAuthToken(username, env);

  return jsonResponse({
    ok: true,
    username,
    token: tokenInfo.token,
    expiresAt: tokenInfo.expiresAt,
  });
}

async function handleSession(request, env) {
  const payload = await requireAdmin(request, env);

  return jsonResponse({
    ok: true,
    username: payload.sub,
    expiresAt: new Date(payload.exp * 1000).toISOString(),
  });
}

async function handlePublish(request, env) {
  const payload = await requireAdmin(request, env);
  const body = await request.json().catch(() => null);
  const snapshot = body?.snapshot ?? null;
  validateSnapshot(snapshot);

  const sourceFileName = String(snapshot?.meta?.sourceFileName ?? 'tariff-snapshot.json');
  const sourceFileLastModified = snapshot?.meta?.sourceFileLastModified ?? null;
  const uploadedAt = snapshot?.meta?.uploadedAt ?? new Date().toISOString();
  const checksumSha256 = await sha256Hex(JSON.stringify(snapshot));
  const snapshotToStore = {
    ...snapshot,
    meta: {
      ...snapshot?.meta,
      sourceFileName,
      sourceFileLastModified,
      uploadedAt,
      publishedByEmail: payload.sub,
      checksumSha256,
    },
  };

  const snapshotJson = `${JSON.stringify(snapshotToStore, null, 2)}
`;

  await env.SNAPSHOT_BUCKET.put('latest/tariff-snapshot.json', snapshotJson, {
    httpMetadata: {
      contentType: 'application/json; charset=utf-8',
      cacheControl: 'no-store',
    },
    customMetadata: {
      checksumSha256,
      uploadedAt,
      publishedByEmail: payload.sub,
      sourceFileName,
      sourceFileLastModified: sourceFileLastModified ?? '',
    },
  });

  return jsonResponse({
    ok: true,
    snapshot: snapshotToStore,
  });
}

async function handleGetSnapshot(env) {
  const object = await env.SNAPSHOT_BUCKET.get('latest/tariff-snapshot.json');

  if (!object) {
    return errorResponse('공용 최신 스냅샷이 아직 없습니다.', 404);
  }

  const text = await object.text();
  const headers = new Headers(getCorsHeaders());
  headers.set('Content-Type', object.httpMetadata?.contentType ?? 'application/json; charset=utf-8');
  headers.set('Cache-Control', 'no-store');

  if (object.httpEtag) {
    headers.set('ETag', object.httpEtag);
  }

  return new Response(text, {
    status: 200,
    headers,
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === 'OPTIONS') {
      return emptyResponse();
    }

    try {
      if (url.pathname === '/health' && request.method === 'GET') {
        return jsonResponse({ ok: true });
      }

      if (url.pathname === '/auth/login' && request.method === 'POST') {
        return await handleLogin(request, env);
      }

      if (url.pathname === '/auth/session' && request.method === 'GET') {
        return await handleSession(request, env);
      }

      if (url.pathname === '/admin/publish' && request.method === 'POST') {
        return await handlePublish(request, env);
      }

      if (url.pathname === '/snapshot' && request.method === 'GET') {
        return await handleGetSnapshot(env);
      }

      return errorResponse('Not found', 404);
    } catch (error) {
      const status = Number.isInteger(error?.status) ? error.status : 500;
      const message = error instanceof Error ? error.message : 'Internal Server Error';
      return errorResponse(message, status);
    }
  },
};
