import { useEffect, useMemo, useRef, useState } from 'react';
import DetailSection from './components/DetailSection.jsx';
import EmptyState from './components/EmptyState.jsx';
import FilterPanel from './components/FilterPanel.jsx';
import GraphSection from './components/GraphSection.jsx';
import MetaPanel from './components/MetaPanel.jsx';
import {
  PUBLISH_API_CONFIG,
  formatPublishError,
  getCurrentAuthUser,
  getPublishSourceLabel,
  getSnapshotVersionKey,
  loadPublishedSnapshot,
  publishWorkbookFile,
  signInAdminWithPassword,
  signOutAdmin,
  validateStoredSession,
} from './lib/publishApiClient.js';
import {
  buildDetailCards,
  buildExportCountryGroups,
  buildGraphModel,
  buildImportCountryGroups,
  getProduct,
  getProductOptions,
  getViewMode,
} from './lib/tariffViewModel.js';

const DEFAULT_FILTERS = {
  productId: '',
  importContinent: '',
  importCountry: '',
  exportContinent: '',
  exportCountry: '',
};

async function loadBundledSnapshot() {
  const response = await fetch(`${import.meta.env.BASE_URL}data/tariff-snapshot.json`, {
    cache: 'no-store',
  });

  if (!response.ok) {
    throw new Error(`데이터 파일을 불러오지 못했습니다. HTTP ${response.status}`);
  }

  return response.json();
}

function decorateSnapshot(snapshot, storageMode) {
  return {
    ...snapshot,
    meta: {
      ...snapshot?.meta,
      storageMode,
    },
  };
}

function normalizeFiltersForSnapshot(snapshot, currentFilters) {
  if (!snapshot) {
    return DEFAULT_FILTERS;
  }

  const nextFilters = {
    ...DEFAULT_FILTERS,
    ...currentFilters,
  };
  const product = getProduct(snapshot, nextFilters.productId);

  if (!product) {
    return DEFAULT_FILTERS;
  }

  const validImportContinents = new Set(
    (product.availableImportCountries ?? []).map((item) => item.continent),
  );
  if (!validImportContinents.has(nextFilters.importContinent)) {
    nextFilters.importContinent = '';
    nextFilters.importCountry = '';
  }

  const validImportCountries = new Set(
    (product.availableImportCountries ?? [])
      .filter((item) => !nextFilters.importContinent || item.continent === nextFilters.importContinent)
      .map((item) => item.country),
  );
  if (nextFilters.importCountry && !validImportCountries.has(nextFilters.importCountry)) {
    nextFilters.importCountry = '';
  }

  const validExportContinents = new Set(
    (product.availableExportCountries ?? []).map((item) => item.continent),
  );
  if (!validExportContinents.has(nextFilters.exportContinent)) {
    nextFilters.exportContinent = '';
    nextFilters.exportCountry = '';
  }

  const validExportCountries = new Set(
    (product.availableExportCountries ?? [])
      .filter((item) => !nextFilters.exportContinent || item.continent === nextFilters.exportContinent)
      .map((item) => item.country),
  );
  if (nextFilters.exportCountry && !validExportCountries.has(nextFilters.exportCountry)) {
    nextFilters.exportCountry = '';
  }

  return nextFilters;
}

export default function App() {
  const [snapshot, setSnapshot] = useState(null);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [collapsedGroups, setCollapsedGroups] = useState({});
  const [status, setStatus] = useState({
    loading: true,
    error: '',
  });
  const [updateState, setUpdateState] = useState({
    loading: false,
    error: '',
    message: '',
  });
  const [authState, setAuthState] = useState({
    ready: !PUBLISH_API_CONFIG.enabled,
    loading: false,
    user: null,
    isAdmin: false,
    error: '',
    message: '',
  });
  const latestSnapshotVersionRef = useRef('');

  useEffect(() => {
    let active = true;

    async function bootstrapSnapshot() {
      let bundledSnapshot = null;
      let bundledError = null;
      let liveSnapshotResult = null;

      try {
        bundledSnapshot = decorateSnapshot(await loadBundledSnapshot(), 'static-published');
      } catch (error) {
        bundledError = error;
      }

      if (PUBLISH_API_CONFIG.enabled) {
        try {
          liveSnapshotResult = await loadPublishedSnapshot();
        } catch (error) {
          console.warn('[tariff] live snapshot bootstrap failed:', error);
        }
      }

      if (!active) {
        return;
      }

      const preferredSnapshot = liveSnapshotResult?.snapshot ?? bundledSnapshot;

      if (!preferredSnapshot) {
        const fallbackError = bundledError instanceof Error
          ? bundledError.message
          : '조회 가능한 관세 데이터가 없습니다.';
        setStatus({ loading: false, error: fallbackError });
        return;
      }

      latestSnapshotVersionRef.current = getSnapshotVersionKey(preferredSnapshot);
      setSnapshot(preferredSnapshot);
      setStatus({ loading: false, error: '' });
    }

    void bootstrapSnapshot();

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!snapshot) {
      return;
    }

    setFilters((current) => normalizeFiltersForSnapshot(snapshot, current));
  }, [snapshot]);

  useEffect(() => {
    if (!PUBLISH_API_CONFIG.enabled) {
      return undefined;
    }

    let active = true;

    async function bootstrapAdminUser() {
      setAuthState((current) => ({
        ...current,
        ready: true,
        loading: true,
        error: '',
      }));

      try {
        const validatedUser = await validateStoredSession();
        const currentUser = validatedUser ?? (await getCurrentAuthUser());

        if (!active) {
          return;
        }

        setAuthState({
          ready: true,
          loading: false,
          user: currentUser,
          isAdmin: Boolean(currentUser),
          error: '',
          message: '',
        });
      } catch (error) {
        if (!active) {
          return;
        }

        setAuthState({
          ready: true,
          loading: false,
          user: null,
          isAdmin: false,
          error: formatPublishError(error),
          message: '',
        });
      }
    }

    void bootstrapAdminUser();

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!PUBLISH_API_CONFIG.enabled) {
      return undefined;
    }

    let active = true;

    async function refreshLiveSnapshot(announce) {
      try {
        const nextResult = await loadPublishedSnapshot();

        if (!active || !nextResult?.snapshot) {
          return;
        }

        const nextVersionKey = getSnapshotVersionKey(nextResult.snapshot);
        if (nextVersionKey && nextVersionKey === latestSnapshotVersionRef.current) {
          return;
        }

        latestSnapshotVersionRef.current = nextVersionKey;
        setSnapshot(nextResult.snapshot);

        if (announce) {
          setUpdateState((current) => ({
            ...current,
            error: '',
            message: '공용 최신 관세조건표가 반영되어 화면을 자동으로 갱신했습니다.',
          }));
        }
      } catch (error) {
        if (!active) {
          return;
        }

        console.warn('[tariff] live snapshot refresh failed:', error);
      }
    }

    const timerId = window.setInterval(() => {
      if (document.visibilityState === 'visible') {
        void refreshLiveSnapshot(true);
      }
    }, 60000);

    function handleWindowFocus() {
      void refreshLiveSnapshot(false);
    }

    function handleVisibilityChange() {
      if (document.visibilityState === 'visible') {
        void refreshLiveSnapshot(false);
      }
    }

    window.addEventListener('focus', handleWindowFocus);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      active = false;
      window.clearInterval(timerId);
      window.removeEventListener('focus', handleWindowFocus);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  const productOptions = useMemo(() => getProductOptions(snapshot), [snapshot]);
  const selectedProduct = useMemo(
    () => getProduct(snapshot, filters.productId),
    [snapshot, filters.productId],
  );
  const importGroups = useMemo(() => buildImportCountryGroups(selectedProduct), [selectedProduct]);
  const exportGroups = useMemo(() => buildExportCountryGroups(selectedProduct), [selectedProduct]);
  const viewMode = useMemo(() => getViewMode(filters), [filters]);
  const detailCards = useMemo(
    () => buildDetailCards(selectedProduct, filters.importCountry, filters.exportCountry),
    [selectedProduct, filters.importCountry, filters.exportCountry],
  );
  const graphModel = useMemo(
    () => buildGraphModel(selectedProduct, filters),
    [selectedProduct, filters],
  );

  function resetAllFilters() {
    setFilters(DEFAULT_FILTERS);
    setCollapsedGroups({});
  }

  function handleProductChange(productId) {
    setFilters({
      ...DEFAULT_FILTERS,
      productId,
    });
    setCollapsedGroups({});
  }

  function handleImportContinentChange(importContinent) {
    setFilters((current) => ({
      ...current,
      importContinent,
      importCountry: '',
    }));
  }

  function handleImportCountryChange(importCountry) {
    setFilters((current) => ({
      ...current,
      importCountry,
    }));
  }

  function handleExportContinentChange(exportContinent) {
    setFilters((current) => ({
      ...current,
      exportContinent,
      exportCountry: '',
    }));
  }

  function handleExportCountryChange(exportCountry) {
    setFilters((current) => ({
      ...current,
      exportCountry,
    }));
  }

  function toggleGraphGroup(continent) {
    setCollapsedGroups((current) => ({
      ...current,
      [continent]: !current[continent],
    }));
  }

  async function handleAdminSignIn(password) {
    setAuthState((current) => ({
      ...current,
      loading: true,
      error: '',
      message: '',
    }));

    try {
      const signedInUser = await signInAdminWithPassword(password);
      setAuthState({
        ready: true,
        loading: false,
        user: signedInUser,
        isAdmin: true,
        error: '',
        message: '업로드 비밀번호 인증에 성공했습니다.',
      });
    } catch (error) {
      setAuthState({
        ready: true,
        loading: false,
        user: null,
        isAdmin: false,
        error: formatPublishError(error),
        message: '',
      });
    }
  }

  async function handleAdminSignOut() {
    setAuthState((current) => ({
      ...current,
      loading: true,
      error: '',
      message: '',
    }));

    try {
      await signOutAdmin();
      setAuthState({
        ready: true,
        loading: false,
        user: null,
        isAdmin: false,
        error: '',
        message: '업로드 권한 인증을 해제했습니다.',
      });
    } catch (error) {
      setAuthState((current) => ({
        ...current,
        loading: false,
        error: formatPublishError(error),
        message: '',
      }));
    }
  }

  async function handleUpdateFileSelected(file) {
    if (!file) {
      return;
    }

    if (!PUBLISH_API_CONFIG.enabled) {
      setUpdateState({
        loading: false,
        error: '실시간 반영 API가 설정되지 않아 공용 업데이트를 사용할 수 없습니다.',
        message: '',
      });
      return;
    }

    if (!authState.isAdmin) {
      setUpdateState({
        loading: false,
        error: '비밀번호 인증 후에만 관세조건표를 업데이트할 수 있습니다.',
        message: '',
      });
      return;
    }

    setUpdateState({
      loading: true,
      error: '',
      message: '',
    });

    try {
      const nextResult = await publishWorkbookFile(file);
      latestSnapshotVersionRef.current = getSnapshotVersionKey(nextResult.snapshot);
      setSnapshot(nextResult.snapshot);
      setUpdateState({
        loading: false,
        error: '',
        message: `${file.name} 파일로 공용 최신본을 덮어썼습니다. 다른 사용자는 새로고침 또는 자동 확인 시 최신 데이터를 보게 됩니다.`,
      });
    } catch (error) {
      setUpdateState({
        loading: false,
        error: formatPublishError(error),
        message: '',
      });
    }
  }

  if (status.loading) {
    return (
      <div className="app-shell">
        <main className="app">
          <section className="panel loading-state">
            <p>데이터를 불러오는 중입니다.</p>
          </section>
        </main>
      </div>
    );
  }

  if (status.error) {
    return (
      <div className="app-shell">
        <main className="app">
          <section className="panel error-state">
            <h1>데이터를 불러오지 못했습니다.</h1>
            <p>{status.error}</p>
            <button className="button button--primary" type="button" onClick={() => window.location.reload()}>
              다시 시도
            </button>
          </section>
        </main>
      </div>
    );
  }

  return (
    <div className="app-shell">
      <main className="app">
        <FilterPanel
          productOptions={productOptions}
          importGroups={importGroups}
          exportGroups={exportGroups}
          filters={filters}
          onProductChange={handleProductChange}
          onImportContinentChange={handleImportContinentChange}
          onImportCountryChange={handleImportCountryChange}
          onExportContinentChange={handleExportContinentChange}
          onExportCountryChange={handleExportCountryChange}
          onReset={resetAllFilters}
        />

        {viewMode === 'idle' ? <EmptyState type="idle" /> : null}
        {viewMode === 'waiting' ? <EmptyState type="waiting" /> : null}

        {viewMode === 'detail' && detailCards.length === 0 ? <EmptyState type="detail-empty" /> : null}
        {viewMode === 'detail' && detailCards.length > 0 ? (
          <DetailSection product={selectedProduct} cards={detailCards} />
        ) : null}

        {(viewMode === 'graph-by-export' || viewMode === 'graph-by-import') && graphModel ? (
          <GraphSection
            graphModel={graphModel}
            collapsedGroups={collapsedGroups}
            onToggleGroup={toggleGraphGroup}
          />
        ) : null}

        <MetaPanel
          meta={snapshot?.meta}
          selectedProduct={selectedProduct}
          dataSourceLabel={getPublishSourceLabel(snapshot?.meta?.storageMode)}
          isPublishApiEnabled={PUBLISH_API_CONFIG.enabled}
          isAdminAuthenticated={authState.isAdmin}
          authReady={authState.ready}
          authLoading={authState.loading}
          authError={authState.error}
          authMessage={authState.message}
          isUpdating={updateState.loading}
          updateError={updateState.error}
          updateMessage={updateState.message}
          onAdminSignIn={handleAdminSignIn}
          onAdminSignOut={handleAdminSignOut}
          onUpdateFileSelected={handleUpdateFileSelected}
        />
      </main>
    </div>
  );
}
