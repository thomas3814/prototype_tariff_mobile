import { useRef, useState } from 'react';
import { formatDateTimeToKorea } from '../shared/tariffFormat.js';

const EXCEL_ACCEPT_VALUE = [
  '.xlsx',
  '.xlsm',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-excel.sheet.macroEnabled.12',
].join(',');

function AdminAccessCard({
  isPublishApiEnabled,
  isAdminAuthenticated,
  authReady,
  authLoading,
  authError,
  authMessage,
  onAdminSignIn,
  onAdminSignOut,
}) {
  const [password, setPassword] = useState('');

  async function handleSubmit(event) {
    event.preventDefault();
    await onAdminSignIn(password);
    setPassword('');
  }

  return (
    <article className="meta-card meta-card--wide">
      <span className="meta-card__label">업데이트 권한</span>

      {!isPublishApiEnabled ? (
        <>
          <strong className="meta-card__value">실시간 반영 API 미설정</strong>
          <span className="meta-card__subtext">
            .env.local 의 VITE_PUBLISH_API_BASE_URL 을 설정하면 비밀번호 인증 후 최신 파일 1개만 덮어쓸 수 있습니다.
          </span>
        </>
      ) : null}

      {isPublishApiEnabled && !isAdminAuthenticated ? (
        <>
          <strong className="meta-card__value">
            {authReady ? '업로드 비밀번호 인증 필요' : '권한 확인 중'}
          </strong>
          <span className="meta-card__subtext">
            비밀번호를 입력하면 Update 버튼으로 관세조건표 Excel 1개를 최신본으로 덮어쓸 수 있습니다.
          </span>

          <form className="admin-auth-form" onSubmit={handleSubmit}>
            <label className="field">
              <span className="field__label">업로드 비밀번호</span>
              <input
                className="field__control field__control--input"
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="비밀번호 입력"
                autoComplete="current-password"
                disabled={authLoading}
                required
              />
            </label>

            <div className="meta-card__actions">
              <button className="button button--primary" type="submit" disabled={authLoading}>
                {authLoading ? '인증 중...' : '비밀번호 확인'}
              </button>
            </div>
          </form>
        </>
      ) : null}

      {isPublishApiEnabled && isAdminAuthenticated ? (
        <>
          <strong className="meta-card__value">관리자 인증 완료</strong>
          <span className="meta-card__subtext">
            현재 세션에서는 관세조건표 Excel 1개를 공용 최신본으로 덮어쓸 수 있습니다.
          </span>

          <div className="meta-card__actions">
            <button
              className="button button--ghost button--compact"
              type="button"
              onClick={onAdminSignOut}
              disabled={authLoading}
            >
              {authLoading ? '처리 중...' : '인증 해제'}
            </button>
          </div>
        </>
      ) : null}

      {authMessage ? <p className="meta-status meta-status--success">{authMessage}</p> : null}
      {authError ? <p className="meta-status meta-status--error">{authError}</p> : null}
    </article>
  );
}

export default function MetaPanel({
  meta,
  selectedProduct,
  dataSourceLabel,
  isPublishApiEnabled,
  isAdminAuthenticated,
  authReady,
  authLoading,
  authError,
  authMessage,
  isUpdating,
  updateError,
  updateMessage,
  onAdminSignIn,
  onAdminSignOut,
  onUpdateFileSelected,
}) {
  const fileInputRef = useRef(null);
  const updateDisabled = !isPublishApiEnabled || !isAdminAuthenticated || isUpdating || authLoading;

  function handleOpenFilePicker() {
    if (updateDisabled) {
      return;
    }

    fileInputRef.current?.click();
  }

  function handleFileChange(event) {
    const [selectedFile] = event.target.files ?? [];

    if (selectedFile) {
      void onUpdateFileSelected(selectedFile);
    }

    event.target.value = '';
  }

  function getSourceSubtext() {
    if (!isPublishApiEnabled) {
      return 'Cloudflare Worker API를 연결하면 비밀번호 인증 후 최신 파일 1개를 공용 반영할 수 있습니다.';
    }

    if (isAdminAuthenticated) {
      return '관세조건표 Excel 파일 1개를 선택하면 현재 최신본을 바로 덮어씁니다.';
    }

    return 'Update 버튼은 비밀번호 인증 후 활성화됩니다.';
  }

  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <h2>데이터 정보</h2>
        </div>
        <div className="graph-legend">
          <span className={`pill ${isPublishApiEnabled ? 'pill--accent' : ''}`}>{dataSourceLabel}</span>
        </div>
      </div>

      <div className="meta-grid">
        <article className="meta-card meta-card--source">
          <div className="meta-card__top">
            <span className="meta-card__label">원본 파일</span>
            <div className="meta-card__actions">
              <button
                className="button button--secondary button--compact"
                type="button"
                onClick={handleOpenFilePicker}
                disabled={updateDisabled}
                title={updateDisabled ? '비밀번호 인증 후 사용 가능합니다.' : '최신 관세조건표를 반영합니다.'}
              >
                {isUpdating ? '업데이트 중...' : 'Update'}
              </button>
            </div>
          </div>

          <strong className="meta-card__value">{meta?.sourceFileName ?? '-'}</strong>
          <span className="meta-card__subtext">{getSourceSubtext()}</span>

          <input
            ref={fileInputRef}
            className="sr-only"
            type="file"
            accept={EXCEL_ACCEPT_VALUE}
            onChange={handleFileChange}
          />
        </article>

        <article className="meta-card">
          <span className="meta-card__label">업로드 일시</span>
          <strong className="meta-card__value">
            {formatDateTimeToKorea(meta?.uploadedAt ?? meta?.extractedAt)}
          </strong>
        </article>

        <article className="meta-card">
          <span className="meta-card__label">원본 파일 수정일</span>
          <strong className="meta-card__value">
            {formatDateTimeToKorea(meta?.sourceFileLastModified)}
          </strong>
        </article>

        <article className="meta-card">
          <span className="meta-card__label">현재 제품</span>
          <strong className="meta-card__value">{selectedProduct?.label ?? '선택 전'}</strong>
        </article>

        <AdminAccessCard
          isPublishApiEnabled={isPublishApiEnabled}
          isAdminAuthenticated={isAdminAuthenticated}
          authReady={authReady}
          authLoading={authLoading}
          authError={authError}
          authMessage={authMessage}
          onAdminSignIn={onAdminSignIn}
          onAdminSignOut={onAdminSignOut}
        />
      </div>

      {updateMessage ? <p className="meta-status meta-status--success">{updateMessage}</p> : null}
      {updateError ? <p className="meta-status meta-status--error">{updateError}</p> : null}
    </section>
  );
}
