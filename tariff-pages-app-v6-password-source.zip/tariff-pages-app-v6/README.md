# tariff-pages-app

관세 조건 조회 시스템 프론트엔드입니다.

## 실행

```bash
npm install
npm run dev
```

## 공용 최신 반영 구조

- 공개 조회 화면: GitHub Pages
- 비밀번호 인증/업로드 API: Cloudflare Worker
- 최신 JSON 저장소: Cloudflare R2

프론트엔드에서 사용할 API 주소는 `.env.local` 에 설정합니다.

```bash
VITE_PUBLISH_API_BASE_URL=https://your-worker.your-subdomain.workers.dev
```

## 정적 JSON 갱신

기존처럼 로컬에서 엑셀을 JSON으로 변환하려면 아래 스크립트를 사용할 수 있습니다.

```bash
npm run sync:data -- "./your-file.xlsx"
```
